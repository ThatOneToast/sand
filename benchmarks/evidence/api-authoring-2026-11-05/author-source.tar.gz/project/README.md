# Vanilla Expedition

A CLI-only Sand authoring experiment for vanilla Minecraft Java 26.3. This is an exportable adventure vertical slice, not a fully tested release. No native game/server was run.

Players receive a custom expedition compass on first join. A Quick Actions journal explains objectives and can cosmetically inscribe held equipment. Five entity kills award a Pathfinder sword and a five-second personal text-display celebration. Entering the Nether grants an advancement, experience, a golden apple, and randomized supplies. Nether explorers see periodic objective guidance. State is per player; the season banner is intentionally global.

Representative resource samples include a flat sanctuary dimension/type, a vanilla trail-ruins structure set, a typed custom enchantment, loot, predicate, modifier, item tag, recipe, dialog, and advancements. The operator function `vanilla_expedition:establish_camp` replaces air at the current position with a campfire. Sanctuary access and richer worldgen are deliberately deferred.

Build from this directory:

```sh
CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_INCREMENTAL=0 /tmp/sand-api-authoring-2026-11-05/bin/sand build --timings
CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_INCREMENTAL=0 /tmp/sand-api-authoring-2026-11-05/bin/sand check
python3 ../evidence/verify_export.py
cargo fmt --check
```

Output: `dist/vanilla_expedition`. Evidence, exact discovery queries, repair logs, feature matrix, independent scores, and deferred areas are in `../evidence/diary.md` and `../evidence/assessment.md`.
