import json,sys
open('/tmp/sand-api-authoring-2026-11-05/evidence/queries.log','a').write('catalog query '+repr(sys.argv[1:])+'\n')
es=json.load(open('/tmp/sand-api-authoring-2026-11-05/evidence/catalog.json'))['entries']
for q in sys.argv[1:]:
 print('\nQUERY',q)
 for e in es:
  p=e['canonical_path']
  if (q.endswith('*') and p.startswith(q[:-1])) or p==q or (q.startswith('?') and q[1:].lower() in p.lower()):
   print(p, e.get('signature',''), '\n',e.get('summary',''))
   if not q.startswith('?') and not q.endswith('*'): print('Context:',e.get('context',''),'\nExample:',e.get('example',''))
