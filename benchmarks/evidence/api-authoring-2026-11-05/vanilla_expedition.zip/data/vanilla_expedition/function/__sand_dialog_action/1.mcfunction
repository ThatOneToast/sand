scoreboard players set @s sd3357f56cf49efc 0
return run function vanilla_expedition:journal