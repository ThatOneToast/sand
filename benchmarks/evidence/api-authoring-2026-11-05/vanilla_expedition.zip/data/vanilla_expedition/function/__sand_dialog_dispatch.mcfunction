execute if score @s sd3357f56cf49efc matches 1 run return run function vanilla_expedition:__sand_dialog_action/1
execute if score @s sd3357f56cf49efc matches 2 run return run function vanilla_expedition:__sand_dialog_action/2
scoreboard players set @s sd3357f56cf49efc 0