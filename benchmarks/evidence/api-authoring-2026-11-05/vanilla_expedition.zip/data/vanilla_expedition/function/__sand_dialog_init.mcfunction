scoreboard objectives add sd3357f56cf49efc trigger
scoreboard players reset * sd3357f56cf49efc
scoreboard players enable @a sd3357f56cf49efc