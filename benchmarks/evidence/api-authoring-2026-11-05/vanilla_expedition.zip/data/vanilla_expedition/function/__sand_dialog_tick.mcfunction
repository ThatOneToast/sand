execute as @a unless score @s sd3357f56cf49efc matches 0 at @s run function vanilla_expedition:__sand_dialog_dispatch
scoreboard players enable @a sd3357f56cf49efc