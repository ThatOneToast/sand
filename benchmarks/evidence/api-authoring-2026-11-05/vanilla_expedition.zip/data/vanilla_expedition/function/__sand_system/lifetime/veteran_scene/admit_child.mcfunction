execute unless dimension minecraft:overworld unless dimension minecraft:the_end unless dimension minecraft:the_nether run return 0
execute unless entity @s[type=minecraft:player] run return 0
execute if entity @s[nbt={Health:0.0f}] run return 0
execute unless score #epoch s472e60cb35d7852 matches 1..2147483646 run return 0
execute unless score #live sc337f00425f66db matches ..127 run return 0
execute unless score #next sa55d5f5a467651b matches ..2147483645 run return 0
execute unless score @s sa55d5f5a467651b matches 1.. run scoreboard players add #next sa55d5f5a467651b 1
execute unless score @s sa55d5f5a467651b matches 1.. run scoreboard players operation @s sa55d5f5a467651b = #next sa55d5f5a467651b
scoreboard players add @s s45142edca9bbf03 0
execute unless score @s s45142edca9bbf03 matches ..2147483646 run return 0
execute store result storage vanilla_expedition:__sand_runtime spawn.generation int 1 run scoreboard players get @s s45142edca9bbf03
execute store result storage vanilla_expedition:__sand_runtime spawn.owner int 1 run scoreboard players get @s sa55d5f5a467651b
scoreboard players add #next sa55d5f5a467651b 1
execute store result storage vanilla_expedition:__sand_runtime spawn.instance int 1 run scoreboard players get #next sa55d5f5a467651b
execute store result storage vanilla_expedition:__sand_runtime spawn.epoch int 1 run scoreboard players get #epoch s472e60cb35d7852
$data modify storage vanilla_expedition:__sand_runtime spawn.ancestors set value $(ancestors)
$data modify storage vanilla_expedition:__sand_runtime spawn.ancestors append value {ledger:"$(parent_ledger)",instance:$(parent)}
execute at @s rotated as @s anchored feet positioned ^ ^ ^ summon minecraft:marker run function vanilla_expedition:__sand_system/lifetime/veteran_scene/init_child with storage vanilla_expedition:__sand_runtime spawn
data remove storage vanilla_expedition:__sand_runtime spawn