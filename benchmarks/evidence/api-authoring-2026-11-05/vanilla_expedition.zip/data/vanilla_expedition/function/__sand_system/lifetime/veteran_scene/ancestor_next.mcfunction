execute unless data storage vanilla_expedition:__sand_runtime ancestry[0] run return 1
execute store result score #ancestor sc337f00425f66db run function vanilla_expedition:__sand_system/lifetime/veteran_scene/ancestor_present with storage vanilla_expedition:__sand_runtime ancestry[0]
execute unless score #ancestor sc337f00425f66db matches 1 run return 0
data remove storage vanilla_expedition:__sand_runtime ancestry[0]
return run function vanilla_expedition:__sand_system/lifetime/veteran_scene/ancestor_next