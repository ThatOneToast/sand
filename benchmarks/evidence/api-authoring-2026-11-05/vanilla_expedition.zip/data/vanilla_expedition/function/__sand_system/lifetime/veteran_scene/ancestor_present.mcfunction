$execute if data storage $(ledger) active[{instance:$(instance)}] run return 1
return 0