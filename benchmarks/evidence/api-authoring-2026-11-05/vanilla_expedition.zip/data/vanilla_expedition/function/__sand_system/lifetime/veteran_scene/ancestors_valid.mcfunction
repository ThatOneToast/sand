data modify storage vanilla_expedition:__sand_runtime ancestry set from entity @s data.ancestors
execute store result score #ancestors sc337f00425f66db run function vanilla_expedition:__sand_system/lifetime/veteran_scene/ancestor_next
data remove storage vanilla_expedition:__sand_runtime ancestry
return run scoreboard players get #ancestors sc337f00425f66db