execute unless score @s sa55d5f5a467651b matches 1.. run return 0
execute store result storage vanilla_expedition:__sand_runtime cancel.generation int 1 run scoreboard players get @s s45142edca9bbf03
execute if score @s s45142edca9bbf03 matches ..2147483646 run scoreboard players add @s s45142edca9bbf03 1
execute store result storage vanilla_expedition:__sand_runtime cancel.owner int 1 run scoreboard players get @s sa55d5f5a467651b
function vanilla_expedition:__sand_system/lifetime/veteran_scene/cancel_owner with storage vanilla_expedition:__sand_runtime cancel
data remove storage vanilla_expedition:__sand_runtime cancel