$execute unless data storage $(ledger) active[{instance:$(instance)}] run return 0
$execute store result score #children sc337f00425f66db run data get storage $(ledger) active[{instance:$(instance)}].children
scoreboard players remove #children sc337f00425f66db 1
$execute store result storage $(ledger) active[{instance:$(instance)}].children int 1 run scoreboard players get #children sc337f00425f66db