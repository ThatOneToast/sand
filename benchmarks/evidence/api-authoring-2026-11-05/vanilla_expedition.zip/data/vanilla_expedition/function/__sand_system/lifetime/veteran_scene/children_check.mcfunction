$execute if data storage vanilla_expedition:__sand_system/lifetime/veteran_scene/task_ledger active[{instance:$(instance),children:0}] run return 1
return 0