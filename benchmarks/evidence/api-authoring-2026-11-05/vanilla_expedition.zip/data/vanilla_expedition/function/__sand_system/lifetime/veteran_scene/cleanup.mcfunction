tag @s remove sand.task.76616e696c6c615f65787065646974696f6e3a7665746572616e5f7363656e65
scoreboard players reset @s sa55d5f5a467651b
scoreboard players reset @s s472e60cb35d7852
scoreboard players reset @s s45dc992db6845f7
scoreboard players reset @s s7df7d535bea556c
scoreboard players reset @s sc337f00425f66db
scoreboard players reset @s sd6245002783fc59
kill @s