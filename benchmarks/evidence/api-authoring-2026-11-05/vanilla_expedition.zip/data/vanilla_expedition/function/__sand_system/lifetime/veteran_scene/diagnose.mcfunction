execute unless entity @s[type=minecraft:player] run return 0
tellraw @s {"text":"Activation checks for vanilla_expedition:veteran_scene"}
execute if score #live sc337f00425f66db matches 128.. run tellraw @s {"text":"Lifetime capacity is exhausted"}
execute if score #next sa55d5f5a467651b matches 2147483646.. run tellraw @s {"text":"Runtime identity space is exhausted"}
tellraw @s [{"text":"Active instances: "},{"score":{"name":"#live","objective":"sc337f00425f66db"}},{"text":" / 128"}]