execute if score @s s7df7d535bea556c matches ..0 run scoreboard players set @s s7df7d535bea556c 1
scoreboard players remove @s s45dc992db6845f7 1
execute if score @s s45dc992db6845f7 matches ..0 run function vanilla_expedition:__sand_system/lifetime/veteran_scene/stop