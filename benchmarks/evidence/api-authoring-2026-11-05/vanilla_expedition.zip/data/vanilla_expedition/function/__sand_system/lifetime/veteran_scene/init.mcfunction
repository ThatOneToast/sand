tag @s add sand.owned
execute unless data entity @s data.ancestors run data modify entity @s data.ancestors set value []
data modify entity @s data.stop set value "vanilla_expedition:__sand_system/lifetime/veteran_scene/stop"
execute unless data storage vanilla_expedition:__sand_system/lifetime/veteran_scene/task_ledger active run data modify storage vanilla_expedition:__sand_system/lifetime/veteran_scene/task_ledger active set value []
$data modify storage vanilla_expedition:__sand_system/lifetime/veteran_scene/task_ledger active append value {instance:$(instance),owner:$(owner),generation:$(generation),children:0}
tag @s add sand.task.76616e696c6c615f65787065646974696f6e3a7665746572616e5f7363656e65
$data merge entity @s {data:{owner:$(owner),instance:$(instance),epoch:$(epoch),generation:$(generation)}}
$scoreboard players set @s sa55d5f5a467651b $(instance)
$scoreboard players set @s s472e60cb35d7852 $(epoch)
scoreboard players set @s s45dc992db6845f7 100
scoreboard players set @s s7df7d535bea556c 1
scoreboard players set @s sc337f00425f66db 1
scoreboard players add #live sc337f00425f66db 1
tp @s ~ ~ ~ ~ ~
function vanilla_expedition:__sand_system/lifetime/veteran_scene/commit
execute unless entity @s[type=minecraft:marker,tag=sand.task.76616e696c6c615f65787065646974696f6e3a7665746572616e5f7363656e65] run return 0
function vanilla_expedition:__sand_system/lifetime/veteran_scene/started