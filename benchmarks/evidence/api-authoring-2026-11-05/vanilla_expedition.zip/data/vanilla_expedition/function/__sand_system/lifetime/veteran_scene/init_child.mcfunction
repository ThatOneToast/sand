$data modify entity @s data.ancestors set value $(ancestors)
function vanilla_expedition:__sand_system/lifetime/veteran_scene/child_added with entity @s data.ancestors[-1]
$function vanilla_expedition:__sand_system/lifetime/veteran_scene/init {owner:$(owner),instance:$(instance),epoch:$(epoch),generation:$(generation)}