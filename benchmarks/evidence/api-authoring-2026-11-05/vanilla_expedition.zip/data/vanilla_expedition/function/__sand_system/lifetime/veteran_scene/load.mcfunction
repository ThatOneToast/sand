data remove storage vanilla_expedition:__sand_system/lifetime/veteran_scene/task_ledger active
scoreboard players add #next sa55d5f5a467651b 0
scoreboard players add #epoch s472e60cb35d7852 0
execute if score #epoch s472e60cb35d7852 matches ..2147483646 run scoreboard players add #epoch s472e60cb35d7852 1
scoreboard players set #live sc337f00425f66db 0