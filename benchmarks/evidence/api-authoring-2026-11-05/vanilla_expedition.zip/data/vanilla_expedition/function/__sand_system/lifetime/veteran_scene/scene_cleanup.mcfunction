function vanilla_expedition:__sand_system/lifetime/veteran_scene/scene_remove with entity @s data
scoreboard players reset @s sd1afb9413b13e83