scoreboard players set @s sd1afb9413b13e83 0
function vanilla_expedition:__sand_system/lifetime/veteran_scene/scene_spawn with entity @s data