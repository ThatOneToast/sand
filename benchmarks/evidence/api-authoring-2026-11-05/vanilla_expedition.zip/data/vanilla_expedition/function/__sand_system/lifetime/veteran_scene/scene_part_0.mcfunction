tag @s add sand.task.76616e696c6c615f65787065646974696f6e3a7665746572616e5f7363656e65.visual
tag @s add sand.task.76616e696c6c615f65787065646974696f6e3a7665746572616e5f7363656e65.visual.0
$scoreboard players set @s sb927b43bcf4c15b $(instance)
data merge entity @s {text:{color:"gold",text:"Veteran Explorer"},transformation:{translation:[0f,2.5f,0f],scale:[1f,1f,1f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}