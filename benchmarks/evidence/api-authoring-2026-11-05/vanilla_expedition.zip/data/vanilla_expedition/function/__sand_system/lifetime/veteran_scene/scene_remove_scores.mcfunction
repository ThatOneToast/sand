scoreboard players reset @s sb927b43bcf4c15b
kill @s