execute unless score @s s472e60cb35d7852 = #epoch s472e60cb35d7852 run return run function vanilla_expedition:__sand_system/lifetime/veteran_scene/stop
execute if score @s sd6245002783fc59 = #now sd6245002783fc59 run return 0
scoreboard players operation @s sd6245002783fc59 = #now sd6245002783fc59
execute store result score @s sc337f00425f66db run function vanilla_expedition:__sand_system/lifetime/veteran_scene/validate with entity @s data
execute unless score @s sc337f00425f66db matches 1 run return run function vanilla_expedition:__sand_system/lifetime/veteran_scene/stop
scoreboard players remove @s s7df7d535bea556c 1
execute if score @s s7df7d535bea556c matches ..0 run function vanilla_expedition:__sand_system/lifetime/veteran_scene/ticked
function vanilla_expedition:__sand_system/lifetime/veteran_scene/resume_tick with entity @s data