execute if entity @s[tag=sand.task.76616e696c6c615f65787065646974696f6e3a7665746572616e5f7363656e65.stopping] run return 0
tag @s add sand.task.76616e696c6c615f65787065646974696f6e3a7665746572616e5f7363656e65.stopping
function vanilla_expedition:__sand_system/lifetime/veteran_scene/retire with entity @s data
function vanilla_expedition:__sand_system/lifetime/veteran_scene/cancel_descendants with entity @s data
execute if score @s s472e60cb35d7852 = #epoch s472e60cb35d7852 run scoreboard players remove #live sc337f00425f66db 1
function vanilla_expedition:__sand_system/lifetime/veteran_scene/stopped
function vanilla_expedition:__sand_system/lifetime/veteran_scene/resolve_cleanup with entity @s data