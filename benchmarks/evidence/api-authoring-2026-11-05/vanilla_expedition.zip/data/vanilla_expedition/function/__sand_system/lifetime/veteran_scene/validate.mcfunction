execute if data entity @s data.ancestors[0] unless function vanilla_expedition:__sand_system/lifetime/veteran_scene/ancestors_valid run return 0
$execute as @a[scores={sa55d5f5a467651b=$(owner)},limit=1] unless entity @s[nbt={Health:0.0f}] if score @s s45142edca9bbf03 matches $(generation) run return run function vanilla_expedition:__sand_system/lifetime/veteran_scene/owner_valid
return 0