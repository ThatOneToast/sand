scoreboard objectives add s449f4ecf10e2432 dummy
scoreboard players set #sand_system s449f4ecf10e2432 0