scoreboard players add #sand_system s449f4ecf10e2432 1
execute if score #sand_system s449f4ecf10e2432 matches 100.. run execute as @a[scores={s5e4f18ed7beb8c2=1}] at @s run function vanilla_expedition:__sand_system/s449f4ecf10e2432
execute if score #sand_system s449f4ecf10e2432 matches 100.. run scoreboard players set #sand_system s449f4ecf10e2432 0