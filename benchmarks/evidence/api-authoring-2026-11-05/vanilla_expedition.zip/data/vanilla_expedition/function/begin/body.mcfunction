give @s minecraft:compass[custom_data={"vanilla_expedition:field_compass":1b},custom_name={color:"gold",text:"Expedition Compass"},lore=[{text:"Craft supplies, cross dimensions, and earn your charter."}],enchantment_glint_override=true]
team join ve_explorers @s
function vanilla_expedition:journal