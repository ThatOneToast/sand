advancement revoke @s only vanilla_expedition:combat
function vanilla_expedition:combat/body