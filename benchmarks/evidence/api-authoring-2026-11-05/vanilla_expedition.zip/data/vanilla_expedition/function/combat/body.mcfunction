data modify storage sand:__participants snap.96f92574.present set value 0b
data modify storage sand:__participants snap.96f92574.item set value {}
execute if data entity @s SelectedItem run data modify storage sand:__participants snap.96f92574.item set from entity @s SelectedItem
execute if data entity @s SelectedItem run data modify storage sand:__participants snap.96f92574.present set value 1b
function vanilla_expedition:state_mutation/16f13f61
execute if score @s sefa78625fb8f3d0 matches 5 run function vanilla_expedition:veteran_reward
title @s actionbar {"color":"gold","text":"Expedition: encounter recorded"}
data modify storage sand:__participants snap.96f92574.present set value 0b
data modify storage sand:__participants snap.96f92574.item set value {}