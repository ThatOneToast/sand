give @s minecraft:golden_apple
loot give @s loot vanilla_expedition:expedition_cache
execute at @s run particle minecraft:happy_villager ~0 ~0 ~0 0.5 0.5 0.5 0 24 force
playsound minecraft:entity.player.levelup master @s
tellraw @s {"color":"gold","text":"Beyond the frontier! Your expedition charter is complete."}