execute if block ~ ~ ~ minecraft:air run return 1
return 0