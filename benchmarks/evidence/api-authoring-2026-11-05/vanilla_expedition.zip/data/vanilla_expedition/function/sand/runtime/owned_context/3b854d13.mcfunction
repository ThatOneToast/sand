$execute as @a[scores={sa55d5f5a467651b=$(owner)},limit=1] at @s run return run function vanilla_expedition:sand/runtime/owned_body/63fb2bbf
return 0