bossbar set vanilla_expedition:season players @a
schedule function vanilla_expedition:season_pulse 10s replace