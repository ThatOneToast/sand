data modify storage vanilla_expedition:world status set value "Expedition season active"
team add ve_explorers
bossbar add vanilla_expedition:season {"color":"gold","text":"Vanilla Expedition • Explore together"}
bossbar set vanilla_expedition:season max 1
bossbar set vanilla_expedition:season value 1
function vanilla_expedition:season_pulse