scoreboard players add @s sefa78625fb8f3d0 1
scoreboard players set @s s42f0b09a12c1ea2 1
scoreboard players set @s s61165e2a5c9989e 1