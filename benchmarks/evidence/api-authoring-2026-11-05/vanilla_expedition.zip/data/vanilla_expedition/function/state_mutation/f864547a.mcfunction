scoreboard players add @s s9b5cf7f5a299c32 1
scoreboard players set @s s9c20ec57959847c 1
scoreboard players set @s s61165e2a5c9989e 1