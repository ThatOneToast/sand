advancement revoke @s only vanilla_expedition:travel
function vanilla_expedition:travel/body