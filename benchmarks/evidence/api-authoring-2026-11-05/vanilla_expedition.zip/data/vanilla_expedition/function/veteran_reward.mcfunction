give @s minecraft:iron_sword[custom_name={color:"gold",text:"Pathfinder Blade"},enchantments={"vanilla_expedition:pathfinder":1}]
function vanilla_expedition:__sand_system/lifetime/veteran_scene/start