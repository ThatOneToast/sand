scoreboard players set @s s0d060a726b36705 0
scoreboard players set @s s123460b5c79ff41 0