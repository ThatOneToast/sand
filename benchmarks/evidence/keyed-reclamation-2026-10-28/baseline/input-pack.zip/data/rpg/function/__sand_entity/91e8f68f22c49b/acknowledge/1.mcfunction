scoreboard players set @s sb635d38a1fd760c 0
scoreboard players set @s s837f5ba71da92da 0