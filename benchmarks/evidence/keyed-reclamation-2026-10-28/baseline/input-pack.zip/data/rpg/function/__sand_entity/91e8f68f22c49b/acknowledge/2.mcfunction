scoreboard players set @s s14a36ee284cf795 0
scoreboard players set @s sda26df8c2d78ff1 0