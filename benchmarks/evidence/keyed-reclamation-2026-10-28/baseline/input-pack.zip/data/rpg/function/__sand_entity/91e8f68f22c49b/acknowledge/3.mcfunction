scoreboard players set @s s658f3e612e120f6 0
scoreboard players set @s s82a27a5964aaa2c 0