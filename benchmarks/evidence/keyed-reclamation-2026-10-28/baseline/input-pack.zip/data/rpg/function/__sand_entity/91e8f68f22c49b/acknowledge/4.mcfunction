scoreboard players set @s s31c5a433d4076b1 0
scoreboard players set @s sb59393c51893935 0