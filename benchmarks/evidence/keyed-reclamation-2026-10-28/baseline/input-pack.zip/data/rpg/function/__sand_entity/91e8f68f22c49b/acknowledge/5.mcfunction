scoreboard players set @s s3f5c128229f19f2 0
scoreboard players set @s s3c0bec0765a5750 0