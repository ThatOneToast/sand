scoreboard players set @s s02a1efa4e0a41b7 0
scoreboard players set @s s3ba0534f1dd54b3 0