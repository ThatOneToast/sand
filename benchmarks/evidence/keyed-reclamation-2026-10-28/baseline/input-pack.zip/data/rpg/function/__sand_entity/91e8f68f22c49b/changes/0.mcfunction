execute if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s123460b5c79ff41 0
execute unless score @s s060804ed46c2240 matches 1 if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s123460b5c79ff41 1
execute if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s0d060a726b36705 1
scoreboard players set @s s8b29157c7024c3d 0