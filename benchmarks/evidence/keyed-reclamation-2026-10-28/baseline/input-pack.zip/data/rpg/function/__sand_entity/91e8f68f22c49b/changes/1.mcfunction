execute if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s837f5ba71da92da 0
execute unless score @s saa4bad269adcfb1 matches 1 if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s837f5ba71da92da 1
execute if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s sb635d38a1fd760c 1
scoreboard players set @s sd0045cb1fdd0d57 0