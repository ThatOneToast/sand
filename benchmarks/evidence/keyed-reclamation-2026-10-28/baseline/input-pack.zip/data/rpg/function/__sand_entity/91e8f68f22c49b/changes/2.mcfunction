execute if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s sda26df8c2d78ff1 0
execute unless score @s sdc78ab42001b010 matches 1 if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s sda26df8c2d78ff1 1
execute if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s14a36ee284cf795 1
scoreboard players set @s sb848191c0c21fa9 0