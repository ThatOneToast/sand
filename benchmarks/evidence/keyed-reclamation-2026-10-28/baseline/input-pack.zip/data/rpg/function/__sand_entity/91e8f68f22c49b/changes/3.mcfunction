execute if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s82a27a5964aaa2c 0
execute unless score @s s18371d7abb9349f matches 1 if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s82a27a5964aaa2c 1
execute if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s658f3e612e120f6 1
scoreboard players set @s s06bfe54886411ef 0