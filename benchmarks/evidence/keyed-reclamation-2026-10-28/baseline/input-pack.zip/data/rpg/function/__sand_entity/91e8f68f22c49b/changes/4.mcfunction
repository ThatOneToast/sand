execute if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s sb59393c51893935 0
execute unless score @s s954e4e6406778bc matches 1 if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s sb59393c51893935 1
execute if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s31c5a433d4076b1 1
scoreboard players set @s s7b98a5795bc20c5 0