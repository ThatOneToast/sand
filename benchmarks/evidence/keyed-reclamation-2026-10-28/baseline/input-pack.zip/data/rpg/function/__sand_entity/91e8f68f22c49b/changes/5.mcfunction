execute if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s3c0bec0765a5750 0
execute unless score @s s573b960db2216bb matches 1 if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s3c0bec0765a5750 1
execute if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s3f5c128229f19f2 1
scoreboard players set @s sc227ef935bce78d 0