execute if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s3ba0534f1dd54b3 0
execute unless score @s sb1ed806f89e8006 matches 1 if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s3ba0534f1dd54b3 1
execute if entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players set @s s02a1efa4e0a41b7 1
scoreboard players set @s sd1f3dd6c3704160 0