scoreboard players reset @s s4f1c993b1021717
scoreboard players reset @s sb848191c0c21fa9
scoreboard players reset @s se1e159acc58be35
scoreboard players reset @s s107b0821dd576e3
scoreboard players reset @s se09bae1a255736b
scoreboard players reset @s s7b98a5795bc20c5
scoreboard players reset @s sfe8d54b59e2dece
scoreboard players reset @s sd1f3dd6c3704160
scoreboard players reset @s s5bd00e734ccd771
execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
function unified_state:sand/state_data/keyed/753e87f8 with storage rpg:state __sand_owner
function unified_state:sand/state_data/keyed/c8ee2444 with storage rpg:state __sand_owner
scoreboard players reset @s s2eb987913797037
scoreboard players reset @s s0e7e180252e8293
scoreboard players reset @s s8b29157c7024c3d
scoreboard players reset @s sf6b3b5339f91c43
scoreboard players reset @s sc227ef935bce78d
scoreboard players reset @s s3e301140ad719cb
scoreboard players reset @s s6df686008bc2641
scoreboard players reset @s s615dcd33728ccd5
scoreboard players reset @s s06bfe54886411ef
scoreboard players reset @s s1e0781fcab3a98d
scoreboard players reset @s sd0045cb1fdd0d57
scoreboard players reset @s s48c028b4287d06b
scoreboard players reset @s saccea77c2a68f21
scoreboard players reset @s s060804ed46c2240
scoreboard players reset @s saa4bad269adcfb1
scoreboard players reset @s sdc78ab42001b010
scoreboard players reset @s s18371d7abb9349f
scoreboard players reset @s s954e4e6406778bc
scoreboard players reset @s s573b960db2216bb
scoreboard players reset @s sb1ed806f89e8006
scoreboard players reset @s s902d876452658c1
scoreboard players reset @s sd97575c4054d706
scoreboard players reset @s s0d060a726b36705
scoreboard players reset @s s123460b5c79ff41
scoreboard players reset @s sb635d38a1fd760c
scoreboard players reset @s s837f5ba71da92da
scoreboard players reset @s s14a36ee284cf795
scoreboard players reset @s sda26df8c2d78ff1
scoreboard players reset @s s658f3e612e120f6
scoreboard players reset @s s82a27a5964aaa2c
scoreboard players reset @s s31c5a433d4076b1
scoreboard players reset @s sb59393c51893935
scoreboard players reset @s s3f5c128229f19f2
scoreboard players reset @s s3c0bec0765a5750
scoreboard players reset @s s02a1efa4e0a41b7
scoreboard players reset @s s3ba0534f1dd54b3
tag @s remove __sand.a.91e8f68f22c49b
tag @s remove __sand.external.91e8f68f22c49b