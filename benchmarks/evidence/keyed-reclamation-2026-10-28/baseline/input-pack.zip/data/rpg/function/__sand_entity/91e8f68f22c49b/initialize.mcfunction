function rpg:__sand_entity/91e8f68f22c49b/provision
execute if score @s s8b29157c7024c3d matches 1 run scoreboard players set @s s123460b5c79ff41 0
execute if score @s s8b29157c7024c3d matches 1 unless score @s s060804ed46c2240 matches 1 run scoreboard players set @s s123460b5c79ff41 1
execute if score @s s8b29157c7024c3d matches 1 run scoreboard players set @s s0d060a726b36705 1
execute if score @s sd0045cb1fdd0d57 matches 1 run scoreboard players set @s s837f5ba71da92da 0
execute if score @s sd0045cb1fdd0d57 matches 1 unless score @s saa4bad269adcfb1 matches 1 run scoreboard players set @s s837f5ba71da92da 1
execute if score @s sd0045cb1fdd0d57 matches 1 run scoreboard players set @s sb635d38a1fd760c 1
execute if score @s sb848191c0c21fa9 matches 1 run scoreboard players set @s sda26df8c2d78ff1 0
execute if score @s sb848191c0c21fa9 matches 1 unless score @s sdc78ab42001b010 matches 1 run scoreboard players set @s sda26df8c2d78ff1 1
execute if score @s sb848191c0c21fa9 matches 1 run scoreboard players set @s s14a36ee284cf795 1
execute if score @s s06bfe54886411ef matches 1 run scoreboard players set @s s82a27a5964aaa2c 0
execute if score @s s06bfe54886411ef matches 1 unless score @s s18371d7abb9349f matches 1 run scoreboard players set @s s82a27a5964aaa2c 1
execute if score @s s06bfe54886411ef matches 1 run scoreboard players set @s s658f3e612e120f6 1
execute if score @s s7b98a5795bc20c5 matches 1 run scoreboard players set @s sb59393c51893935 0
execute if score @s s7b98a5795bc20c5 matches 1 unless score @s s954e4e6406778bc matches 1 run scoreboard players set @s sb59393c51893935 1
execute if score @s s7b98a5795bc20c5 matches 1 run scoreboard players set @s s31c5a433d4076b1 1
execute if score @s sc227ef935bce78d matches 1 run scoreboard players set @s s3c0bec0765a5750 0
execute if score @s sc227ef935bce78d matches 1 unless score @s s573b960db2216bb matches 1 run scoreboard players set @s s3c0bec0765a5750 1
execute if score @s sc227ef935bce78d matches 1 run scoreboard players set @s s3f5c128229f19f2 1
execute if score @s sd1f3dd6c3704160 matches 1 run scoreboard players set @s s3ba0534f1dd54b3 0
execute if score @s sd1f3dd6c3704160 matches 1 unless score @s sb1ed806f89e8006 matches 1 run scoreboard players set @s s3ba0534f1dd54b3 1
execute if score @s sd1f3dd6c3704160 matches 1 run scoreboard players set @s s02a1efa4e0a41b7 1
execute if score @s s8b29157c7024c3d matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/0
execute if score @s sd0045cb1fdd0d57 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/1
execute if score @s sb848191c0c21fa9 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/2
execute if score @s s06bfe54886411ef matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/3
execute if score @s s7b98a5795bc20c5 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/4
execute if score @s sc227ef935bce78d matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/5
execute if score @s sd1f3dd6c3704160 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/6
execute unless entity @s[scores={s060804ed46c2240=0,saa4bad269adcfb1=0,sdc78ab42001b010=0,s18371d7abb9349f=0,s954e4e6406778bc=0,s573b960db2216bb=0,sb1ed806f89e8006=0}] run function rpg:__sand_entity/91e8f68f22c49b/reset_internal_causes
scoreboard players set @s s902d876452658c1 1
tag @s add __sand.a.91e8f68f22c49b