execute unless score @s s615dcd33728ccd5 matches -2147483648.. run scoreboard players set @s s615dcd33728ccd5 2
execute unless score @s s1e0781fcab3a98d matches -2147483648.. run scoreboard players set @s s1e0781fcab3a98d 0
execute if score @s saccea77c2a68f21 matches 1 run say migrated attack 1 -> 2
execute if score @s saccea77c2a68f21 matches 1 run scoreboard players set @s saccea77c2a68f21 2
execute unless score @s saccea77c2a68f21 matches 1.. run scoreboard players set @s saccea77c2a68f21 2
execute unless score @s s0e7e180252e8293 matches -2147483648.. run scoreboard players set @s s0e7e180252e8293 0
execute unless score @s sf6b3b5339f91c43 matches -2147483648.. run scoreboard players set @s sf6b3b5339f91c43 0
execute unless score @s s6df686008bc2641 matches 1.. run scoreboard players set @s s6df686008bc2641 1
execute unless score @s se09bae1a255736b matches -2147483648.. run scoreboard players set @s se09bae1a255736b 0
execute unless score @s sfe8d54b59e2dece matches -2147483648.. run scoreboard players set @s sfe8d54b59e2dece 0
execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
function unified_state:sand/state_data/keyed/357d0774 with storage rpg:state __sand_owner
function unified_state:sand/state_data/keyed/0594fae3 with storage rpg:state __sand_owner
execute unless score @s s2eb987913797037 matches 1.. run scoreboard players set @s s2eb987913797037 1
execute unless score @s s4f1c993b1021717 matches -2147483648.. run scoreboard players set @s s4f1c993b1021717 20
execute unless score @s s107b0821dd576e3 matches 1.. run scoreboard players set @s s107b0821dd576e3 1