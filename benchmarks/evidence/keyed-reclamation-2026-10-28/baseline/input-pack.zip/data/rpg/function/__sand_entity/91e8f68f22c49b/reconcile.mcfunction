scoreboard players set @s sd97575c4054d706 0
execute unless score @s saccea77c2a68f21 matches 2 run scoreboard players set @s sd97575c4054d706 1
execute unless score @s s6df686008bc2641 matches 1 run scoreboard players set @s sd97575c4054d706 1
execute unless score @s s2eb987913797037 matches 1 run scoreboard players set @s sd97575c4054d706 1
execute unless score @s s107b0821dd576e3 matches 1 run scoreboard players set @s sd97575c4054d706 1
execute unless score @s s0e7e180252e8293 matches -2147483648.. run scoreboard players set @s sd97575c4054d706 1
execute unless score @s s1e0781fcab3a98d matches -2147483648.. run scoreboard players set @s sd97575c4054d706 1
execute unless score @s s4f1c993b1021717 matches -2147483648.. run scoreboard players set @s sd97575c4054d706 1
execute unless score @s s615dcd33728ccd5 matches -2147483648.. run scoreboard players set @s sd97575c4054d706 1
execute unless score @s se09bae1a255736b matches -2147483648.. run scoreboard players set @s sd97575c4054d706 1
execute unless score @s sf6b3b5339f91c43 matches -2147483648.. run scoreboard players set @s sd97575c4054d706 1
execute unless score @s sfe8d54b59e2dece matches -2147483648.. run scoreboard players set @s sd97575c4054d706 1
function rpg:__sand_entity/91e8f68f22c49b/provision
execute unless score @s s902d876452658c1 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/initialize
execute if score @s s8b29157c7024c3d matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/0
execute if score @s sd0045cb1fdd0d57 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/1
execute if score @s sb848191c0c21fa9 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/2
execute if score @s s06bfe54886411ef matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/3
execute if score @s s7b98a5795bc20c5 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/4
execute if score @s sc227ef935bce78d matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/5
execute if score @s sd1f3dd6c3704160 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/6
execute unless entity @s[scores={s060804ed46c2240=0,saa4bad269adcfb1=0,sdc78ab42001b010=0,s18371d7abb9349f=0,s954e4e6406778bc=0,s573b960db2216bb=0,sb1ed806f89e8006=0}] run function rpg:__sand_entity/91e8f68f22c49b/reset_internal_causes
execute unless entity @s[scores={s0d060a726b36705=0,s123460b5c79ff41=0}] run function rpg:__sand_entity/91e8f68f22c49b/acknowledge/0
execute unless entity @s[scores={sb635d38a1fd760c=0,s837f5ba71da92da=0}] run function rpg:__sand_entity/91e8f68f22c49b/acknowledge/1
execute unless entity @s[scores={s14a36ee284cf795=0,sda26df8c2d78ff1=0}] run function rpg:__sand_entity/91e8f68f22c49b/acknowledge/2
execute unless entity @s[scores={s658f3e612e120f6=0,s82a27a5964aaa2c=0}] run function rpg:__sand_entity/91e8f68f22c49b/acknowledge/3
execute unless entity @s[scores={s31c5a433d4076b1=0,sb59393c51893935=0}] run function rpg:__sand_entity/91e8f68f22c49b/acknowledge/4
execute unless entity @s[scores={s3f5c128229f19f2=0,s3c0bec0765a5750=0}] run function rpg:__sand_entity/91e8f68f22c49b/acknowledge/5
execute unless entity @s[scores={s02a1efa4e0a41b7=0,s3ba0534f1dd54b3=0}] run function rpg:__sand_entity/91e8f68f22c49b/acknowledge/6
execute if score @s s8b29157c7024c3d matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/0
execute if score @s sd0045cb1fdd0d57 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/1
execute if score @s sb848191c0c21fa9 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/2
execute if score @s s06bfe54886411ef matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/3
execute if score @s s7b98a5795bc20c5 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/4
execute if score @s sc227ef935bce78d matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/5
execute if score @s sd1f3dd6c3704160 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/6
execute unless entity @s[scores={s060804ed46c2240=0,saa4bad269adcfb1=0,sdc78ab42001b010=0,s18371d7abb9349f=0,s954e4e6406778bc=0,s573b960db2216bb=0,sb1ed806f89e8006=0}] run function rpg:__sand_entity/91e8f68f22c49b/reset_internal_causes
execute if score @s s8b29157c7024c3d matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/0
execute if score @s sd0045cb1fdd0d57 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/1
execute if score @s sb848191c0c21fa9 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/2
execute if score @s s06bfe54886411ef matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/3
execute if score @s s7b98a5795bc20c5 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/4
execute if score @s sc227ef935bce78d matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/5
execute if score @s sd1f3dd6c3704160 matches 1 run function rpg:__sand_entity/91e8f68f22c49b/changes/6
execute unless entity @s[scores={s060804ed46c2240=0,saa4bad269adcfb1=0,sdc78ab42001b010=0,s18371d7abb9349f=0,s954e4e6406778bc=0,s573b960db2216bb=0,sb1ed806f89e8006=0}] run function rpg:__sand_entity/91e8f68f22c49b/reset_internal_causes