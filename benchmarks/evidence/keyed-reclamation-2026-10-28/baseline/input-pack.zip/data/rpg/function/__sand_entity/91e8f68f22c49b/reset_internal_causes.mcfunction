scoreboard players set @s s060804ed46c2240 0
scoreboard players set @s saa4bad269adcfb1 0
scoreboard players set @s sdc78ab42001b010 0
scoreboard players set @s s18371d7abb9349f 0
scoreboard players set @s s954e4e6406778bc 0
scoreboard players set @s s573b960db2216bb 0
scoreboard players set @s sb1ed806f89e8006 0