scoreboard players add #clock s74f8a5693b27096 1
execute if score #clock s74f8a5693b27096 matches 20.. run function rpg:__sand_entity/91e8f68f22c49b/scan
execute if score #clock s74f8a5693b27096 matches 20.. run scoreboard players set #clock s74f8a5693b27096 0