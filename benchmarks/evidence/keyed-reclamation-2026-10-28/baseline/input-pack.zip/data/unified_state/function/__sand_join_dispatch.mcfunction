scoreboard players set @s __sj_unified_state.p 0
execute if score @s __sj_unified_state.l = @s __sj_unified_state.l run scoreboard players operation @s __sj_unified_state.p = @s __sj_unified_state.l
execute at @s run function unified_state:welcome_player