execute unless score @s s470e8657b456607 matches 1.. unless score @s s6645414d0fbd2ad matches -2147483648.. run scoreboard players set @s s6645414d0fbd2ad 1
execute unless score @s s470e8657b456607 matches 1.. unless score @s sf040c347721ae59 matches -2147483648.. run scoreboard players set @s sf040c347721ae59 0
execute unless score @s s470e8657b456607 matches 1.. unless score @s sb69a74561ae2585 matches -2147483648.. run scoreboard players set @s sb69a74561ae2585 100
execute unless score @s s470e8657b456607 matches 1.. run execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
execute unless score @s s470e8657b456607 matches 1.. run data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
execute unless score @s s470e8657b456607 matches 1.. run function unified_state:sand/state_data/keyed/0b547c35 with storage rpg:state __sand_owner
execute unless score @s s470e8657b456607 matches 1.. run execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
execute unless score @s s470e8657b456607 matches 1.. run data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
execute unless score @s s470e8657b456607 matches 1.. run function unified_state:sand/state_data/keyed/3ad0638a with storage rpg:state __sand_owner
execute unless score @s s470e8657b456607 matches 1.. unless score @s s02089a9adb1b894 matches 1.. run scoreboard players set @s s02089a9adb1b894 1
execute unless score @s s35a3a3e3dbbd5af matches 1.. unless score @s s3f7e518a2ffb194 matches -2147483648.. run scoreboard players set @s s3f7e518a2ffb194 0
execute unless score @s s35a3a3e3dbbd5af matches 1.. unless score @s s52e928aac683b8c matches 1.. run scoreboard players set @s s52e928aac683b8c 1