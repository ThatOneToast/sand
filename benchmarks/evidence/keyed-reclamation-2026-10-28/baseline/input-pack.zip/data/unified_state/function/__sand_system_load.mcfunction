scoreboard objectives add se80f803ff5d6070 dummy
scoreboard players set #sand_system se80f803ff5d6070 0
scoreboard objectives add s5646254cabff619 dummy
scoreboard players set #sand_system s5646254cabff619 0