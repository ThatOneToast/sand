scoreboard players add #sand_system se80f803ff5d6070 1
execute if score #sand_system se80f803ff5d6070 matches 20.. run execute as @e[scores={s6df686008bc2641=1,saccea77c2a68f21=2}] at @s run function unified_state:__sand_system/se80f803ff5d6070
execute if score #sand_system se80f803ff5d6070 matches 20.. run scoreboard players set #sand_system se80f803ff5d6070 0
scoreboard players add #sand_system s5646254cabff619 1
execute if score #sand_system s5646254cabff619 matches 20.. run execute as @e[scores={s107b0821dd576e3=1}] at @s run function unified_state:__sand_system/s5646254cabff619
execute if score #sand_system s5646254cabff619 matches 20.. run scoreboard players set #sand_system s5646254cabff619 0