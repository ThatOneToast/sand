scoreboard players add #sand_rpg_world_102a3fba s08cff6e2a83a8d5 1
function unified_state:state_mutation/41bda90a
function unified_state:state_mutation/0aa3e79a
execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
function unified_state:sand/state_data/keyed/1b8f7998 with storage rpg:state __sand_owner