scoreboard players reset @s s615dcd33728ccd5
scoreboard players reset @s s06bfe54886411ef
scoreboard players reset @s s1e0781fcab3a98d
scoreboard players reset @s sd0045cb1fdd0d57
scoreboard players reset @s s48c028b4287d06b
scoreboard players reset @s saccea77c2a68f21