scoreboard players reset @s se09bae1a255736b
scoreboard players reset @s s7b98a5795bc20c5
scoreboard players reset @s sfe8d54b59e2dece
scoreboard players reset @s sd1f3dd6c3704160
scoreboard players reset @s s5bd00e734ccd771
execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
function unified_state:sand/state_data/keyed/753e87f8 with storage rpg:state __sand_owner
execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
function unified_state:sand/state_data/keyed/c8ee2444 with storage rpg:state __sand_owner
scoreboard players reset @s s2eb987913797037