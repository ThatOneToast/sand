execute unless score @s s615dcd33728ccd5 matches -2147483648.. run scoreboard players set @s s615dcd33728ccd5 2
execute unless score @s s1e0781fcab3a98d matches -2147483648.. run scoreboard players set @s s1e0781fcab3a98d 0
execute if score @s saccea77c2a68f21 matches 1 run say migrated attack 1 -> 2
execute if score @s saccea77c2a68f21 matches 1 run scoreboard players set @s saccea77c2a68f21 2
execute unless score @s saccea77c2a68f21 matches 1.. run scoreboard players set @s saccea77c2a68f21 2