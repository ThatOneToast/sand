scoreboard players set #inventory s975be2331f36860 0
execute as @s run function unified_state:sand/numeric/sac3bbb58dc225b9/3e16a999/inventory_0
execute unless score #inventory s975be2331f36860 matches 1 run return fail
scoreboard players operation @s sbf595ea0915e927 = #inventory s7a81c7dd848418d
scoreboard players operation @s s46ffee5889d1417 = @s sbf595ea0915e927
scoreboard players operation @s s3f7e518a2ffb194 = @s s46ffee5889d1417