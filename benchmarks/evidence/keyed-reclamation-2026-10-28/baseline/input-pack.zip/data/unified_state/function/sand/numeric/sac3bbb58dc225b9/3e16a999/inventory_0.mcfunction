execute unless entity @s[type=minecraft:player] run return fail
scoreboard players set #inventory s975be2331f36860 1
execute store result score #inventory s7a81c7dd848418d run clear @s minecraft:diamond 0