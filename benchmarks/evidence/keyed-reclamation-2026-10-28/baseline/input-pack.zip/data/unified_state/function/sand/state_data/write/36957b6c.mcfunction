data remove storage rpg:state __sand_owner.value
data modify storage rpg:state __sand_owner.value set value "$(u0)"
function unified_state:sand/state_data/keyed/1c3bae1e with storage rpg:state __sand_owner
data remove storage rpg:state __sand_owner.value