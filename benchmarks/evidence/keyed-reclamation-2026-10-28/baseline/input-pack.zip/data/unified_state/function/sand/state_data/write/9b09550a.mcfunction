data remove storage rpg:state __sand_owner.value
data modify storage rpg:state __sand_owner.value set value {stacks:3,note:"kept"}
execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
function unified_state:sand/state_data/keyed/91c6cf1a with storage rpg:state __sand_owner
data remove storage rpg:state __sand_owner.value