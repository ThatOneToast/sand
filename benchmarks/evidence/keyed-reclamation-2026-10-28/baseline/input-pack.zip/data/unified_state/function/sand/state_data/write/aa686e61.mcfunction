data remove storage rpg:state __sand_owner.value
data modify storage rpg:state __sand_owner.value set value {announcements:1b,title:"Rookie"}
function unified_state:sand/state_data/keyed/4bd65c8b with storage rpg:state __sand_owner
data remove storage rpg:state __sand_owner.value