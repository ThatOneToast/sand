data remove storage rpg:state __sand_owner.value
data modify storage rpg:state __sand_owner.value set value "$(player)"
function unified_state:sand/state_data/keyed/07d478fd with storage rpg:state __sand_owner
data remove storage rpg:state __sand_owner.value