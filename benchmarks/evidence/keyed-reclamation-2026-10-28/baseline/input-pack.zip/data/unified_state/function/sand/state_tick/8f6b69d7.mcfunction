execute if score @s s1e0781fcab3a98d matches 1.. run scoreboard players set @s sd0045cb1fdd0d57 1
execute if score @s s1e0781fcab3a98d matches 1.. run scoreboard players set @s s48c028b4287d06b 1
execute if score @s s1e0781fcab3a98d matches 1.. run scoreboard players remove @s s1e0781fcab3a98d 1