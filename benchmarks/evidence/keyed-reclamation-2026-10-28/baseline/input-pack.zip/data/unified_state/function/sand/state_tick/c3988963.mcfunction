execute if score @s sfe8d54b59e2dece matches 1.. run scoreboard players set @s sd1f3dd6c3704160 1
execute if score @s sfe8d54b59e2dece matches 1.. run scoreboard players set @s s5bd00e734ccd771 1
execute if score @s sfe8d54b59e2dece matches 1.. run scoreboard players remove @s sfe8d54b59e2dece 1