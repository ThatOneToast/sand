scoreboard players add @s sb69a74561ae2585 5
execute if score @s sb69a74561ae2585 matches ..-1 run scoreboard players set @s sb69a74561ae2585 0
execute if score @s sb69a74561ae2585 matches 1001.. run scoreboard players set @s sb69a74561ae2585 1000