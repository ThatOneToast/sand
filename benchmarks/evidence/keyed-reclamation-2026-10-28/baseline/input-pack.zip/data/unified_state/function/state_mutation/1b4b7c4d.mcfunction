scoreboard players add @s s0e7e180252e8293 1
execute if score @s s0e7e180252e8293 matches ..-1 run scoreboard players set @s s0e7e180252e8293 0
execute if score @s s0e7e180252e8293 matches 101.. run scoreboard players set @s s0e7e180252e8293 100
scoreboard players set @s s8b29157c7024c3d 1
scoreboard players set @s s3e301140ad719cb 1