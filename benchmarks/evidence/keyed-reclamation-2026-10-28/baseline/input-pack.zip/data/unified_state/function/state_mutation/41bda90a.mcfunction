scoreboard players add @s sf040c347721ae59 10
execute if score @s sf040c347721ae59 matches ..-1 run scoreboard players set @s sf040c347721ae59 0
execute if score @s sf040c347721ae59 matches 1000001.. run scoreboard players set @s sf040c347721ae59 1000000