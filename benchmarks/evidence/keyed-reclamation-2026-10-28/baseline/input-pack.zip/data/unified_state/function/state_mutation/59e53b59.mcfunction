scoreboard players add @s s615dcd33728ccd5 1
execute if score @s s615dcd33728ccd5 matches ..-1 run scoreboard players set @s s615dcd33728ccd5 0
execute if score @s s615dcd33728ccd5 matches 101.. run scoreboard players set @s s615dcd33728ccd5 100
scoreboard players set @s s06bfe54886411ef 1
scoreboard players set @s s48c028b4287d06b 1