scoreboard players add @s s4f1c993b1021717 1
execute if score @s s4f1c993b1021717 matches ..-1 run scoreboard players set @s s4f1c993b1021717 0
execute if score @s s4f1c993b1021717 matches 101.. run scoreboard players set @s s4f1c993b1021717 100
scoreboard players set @s sb848191c0c21fa9 1
scoreboard players set @s se1e159acc58be35 1