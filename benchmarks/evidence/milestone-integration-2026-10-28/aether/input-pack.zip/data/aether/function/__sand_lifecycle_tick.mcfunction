execute as @a run function aether:__sand_lifecycle_init
execute as @a run execute if score @s s9b1907d6dc354f6 matches 1.. if score @s s686ac41c5afb1ae matches 1.. run scoreboard players remove @s s686ac41c5afb1ae 1
execute as @a run execute if score @s s9b1907d6dc354f6 matches 1.. if score @s s7a6a5f24df3bec0 matches 1.. run scoreboard players remove @s s7a6a5f24df3bec0 1
execute as @a run execute if score @s s9b1907d6dc354f6 matches 1.. if score @s safa89ddbad9c6fb matches 1.. run scoreboard players remove @s safa89ddbad9c6fb 1
function aether:recharge