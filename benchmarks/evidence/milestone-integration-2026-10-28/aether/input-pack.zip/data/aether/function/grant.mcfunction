function aether:__sand_lifecycle_init
item replace entity @s weapon.offhand with minecraft:amethyst_shard[custom_data={aether_prism:1b}] 1