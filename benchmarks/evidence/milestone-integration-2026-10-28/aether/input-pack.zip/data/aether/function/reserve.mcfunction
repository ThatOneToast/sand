function aether:__sand_lifecycle_init
execute if score @s safa89ddbad9c6fb matches 0 if score @s s7cf28268f965f61 matches 5.. run function aether:sand/branches/05a76dcb