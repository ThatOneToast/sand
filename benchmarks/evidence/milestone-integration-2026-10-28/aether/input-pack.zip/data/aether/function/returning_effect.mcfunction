function aether:__sand_lifecycle_init
return fail
scoreboard players add @s s2dc7b7f3902677c 1