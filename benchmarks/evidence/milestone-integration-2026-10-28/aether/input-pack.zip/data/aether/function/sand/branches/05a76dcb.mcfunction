function aether:state_mutation/503ecf31
scoreboard players set @s safa89ddbad9c6fb 9
execute if score @s safa89ddbad9c6fb matches ..-1 run scoreboard players set @s safa89ddbad9c6fb 0
scoreboard players add @s s2dc7b7f3902677c 1