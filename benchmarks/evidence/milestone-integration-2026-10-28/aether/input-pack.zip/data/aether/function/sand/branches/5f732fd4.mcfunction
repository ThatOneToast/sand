execute if function aether:sand/conditions/numeric/02c1acef run function aether:state_mutation/3b407d3b
scoreboard players set @s s686ac41c5afb1ae 7
execute if score @s s686ac41c5afb1ae matches ..-1 run scoreboard players set @s s686ac41c5afb1ae 0