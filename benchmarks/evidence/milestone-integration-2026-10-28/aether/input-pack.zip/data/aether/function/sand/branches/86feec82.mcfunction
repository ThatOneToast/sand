function aether:state_mutation/f79cb4bf
scoreboard players set @s s7a6a5f24df3bec0 12
execute if score @s s7a6a5f24df3bec0 matches ..-1 run scoreboard players set @s s7a6a5f24df3bec0 0
scoreboard players add @s s2dc7b7f3902677c 1