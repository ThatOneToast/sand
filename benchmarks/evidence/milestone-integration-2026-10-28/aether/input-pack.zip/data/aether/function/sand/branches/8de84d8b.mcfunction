function aether:state_mutation/67c260fa
scoreboard players set @s s7a6a5f24df3bec0 12
execute if score @s s7a6a5f24df3bec0 matches ..-1 run scoreboard players set @s s7a6a5f24df3bec0 0
setblock 1000000 80 1000000 minecraft:gold_block
scoreboard players add @s s2dc7b7f3902677c 1