execute if block ~ ~-1 ~ minecraft:diamond_block run return 1
return 0