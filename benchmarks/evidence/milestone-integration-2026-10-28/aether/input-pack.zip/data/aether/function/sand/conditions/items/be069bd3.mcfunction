execute if items entity @s weapon.offhand minecraft:amethyst_shard[minecraft:custom_data~{aether_prism:1b}] run return 1
return 0