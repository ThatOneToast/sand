scoreboard players set #comparison s21119272db4e8f8 0
execute store success score #comparison s0eefefe54f9a815 store result score #comparison s21119272db4e8f8 run scoreboard players get @s s19e1ea2f16315e7
execute unless score #comparison s0eefefe54f9a815 matches 1 run return fail
scoreboard players operation #comparison s6a210eee21cce7e = #comparison s21119272db4e8f8
scoreboard players set #comparison s14469454460ebbf 48
scoreboard players operation #comparison s6d06016e7de901f = #comparison s14469454460ebbf
execute if score #comparison s6a210eee21cce7e < #comparison s6d06016e7de901f run return 1
return 0