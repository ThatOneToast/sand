execute unless score @s sed46c3a2f2efd31 matches 1.. unless score @s s19e1ea2f16315e7 matches -2147483648.. run scoreboard players set @s s19e1ea2f16315e7 48
execute unless score @s sed46c3a2f2efd31 matches 1.. unless score @s s686ac41c5afb1ae matches -2147483648.. run scoreboard players set @s s686ac41c5afb1ae 0
execute unless score @s sed46c3a2f2efd31 matches 1.. unless score @s s7a6a5f24df3bec0 matches -2147483648.. run scoreboard players set @s s7a6a5f24df3bec0 0
execute unless score @s sed46c3a2f2efd31 matches 1.. unless score @s s7cf28268f965f61 matches -2147483648.. run scoreboard players set @s s7cf28268f965f61 21
execute unless score @s sed46c3a2f2efd31 matches 1.. unless score @s safa89ddbad9c6fb matches -2147483648.. run scoreboard players set @s safa89ddbad9c6fb 0
execute unless score @s sed46c3a2f2efd31 matches 1.. unless score @s s2dc7b7f3902677c matches -2147483648.. run scoreboard players set @s s2dc7b7f3902677c 0
execute unless score @s sed46c3a2f2efd31 matches 1.. unless score @s s9b1907d6dc354f6 matches 1.. run scoreboard players set @s s9b1907d6dc354f6 1