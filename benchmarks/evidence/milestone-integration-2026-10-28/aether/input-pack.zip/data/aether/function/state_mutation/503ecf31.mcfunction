scoreboard players remove @s s7cf28268f965f61 5
execute if score @s s7cf28268f965f61 matches ..-1 run scoreboard players set @s s7cf28268f965f61 0
execute if score @s s7cf28268f965f61 matches 22.. run scoreboard players set @s s7cf28268f965f61 21