scoreboard players remove @s s19e1ea2f16315e7 11
execute if score @s s19e1ea2f16315e7 matches ..-1 run scoreboard players set @s s19e1ea2f16315e7 0
execute if score @s s19e1ea2f16315e7 matches 49.. run scoreboard players set @s s19e1ea2f16315e7 48