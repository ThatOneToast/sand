scoreboard players set @s s5c0ae00dcbcb155 0
scoreboard players set @s s817c6be26b42ab1 0