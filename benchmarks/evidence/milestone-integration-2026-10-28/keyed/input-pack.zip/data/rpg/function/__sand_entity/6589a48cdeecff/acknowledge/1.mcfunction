scoreboard players set @s sd6c86a30e59ce2b 0
scoreboard players set @s s191aaedbe44070f 0