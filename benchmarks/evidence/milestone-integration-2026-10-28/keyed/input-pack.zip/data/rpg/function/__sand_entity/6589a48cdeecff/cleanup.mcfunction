execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run say SAND_STATUS_CLEANUP
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run scoreboard players get @s se09bae1a255736b
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run function unified_state:sand/state_data/keyed/ce36e3c9 with storage rpg:state __sand_owner
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run execute as @e[tag=keyed_literal_b,limit=1] run execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run execute as @e[tag=keyed_literal_b,limit=1] run data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run execute as @e[tag=keyed_literal_b,limit=1] run function unified_state:sand/state_data/keyed/ce36e3c9 with storage rpg:state __sand_owner
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run scoreboard players reset @s se09bae1a255736b
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run scoreboard players reset @s s7b98a5795bc20c5
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run scoreboard players reset @s sfe8d54b59e2dece
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run scoreboard players reset @s sd1f3dd6c3704160
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run scoreboard players reset @s s5bd00e734ccd771
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run function unified_state:sand/state_data/remove/2f33338e
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run function unified_state:sand/state_data/remove/4b8fb6ae
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run function unified_state:sand/state_data/prune/f6755f91
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run execute if data storage rpg:state __sand_keyed{version:2} run scoreboard players reset @s s2eb987913797037
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players reset @s s954e4e6406778bc
execute unless entity @s[tag=__sand.a.91e8f68f22c49b] run scoreboard players reset @s sb1ed806f89e8006
scoreboard players reset @s s0ba36d9beeab3fd
scoreboard players reset @s s1edcd24c2bebf52
scoreboard players reset @s s5c0ae00dcbcb155
scoreboard players reset @s s817c6be26b42ab1
scoreboard players reset @s sd6c86a30e59ce2b
scoreboard players reset @s s191aaedbe44070f
tag @s remove __sand.a.6589a48cdeecff
tag @s remove __sand.external.6589a48cdeecff