function rpg:__sand_entity/6589a48cdeecff/provision
execute if score @s s7b98a5795bc20c5 matches 1 run scoreboard players set @s s817c6be26b42ab1 0
execute if score @s s7b98a5795bc20c5 matches 1 unless score @s s954e4e6406778bc matches 1 run scoreboard players set @s s817c6be26b42ab1 1
execute if score @s s7b98a5795bc20c5 matches 1 run scoreboard players set @s s5c0ae00dcbcb155 1
execute if score @s sd1f3dd6c3704160 matches 1 run scoreboard players set @s s191aaedbe44070f 0
execute if score @s sd1f3dd6c3704160 matches 1 unless score @s sb1ed806f89e8006 matches 1 run scoreboard players set @s s191aaedbe44070f 1
execute if score @s sd1f3dd6c3704160 matches 1 run scoreboard players set @s sd6c86a30e59ce2b 1
execute if score @s s7b98a5795bc20c5 matches 1 run function rpg:__sand_entity/6589a48cdeecff/changes/0
execute if score @s sd1f3dd6c3704160 matches 1 run function rpg:__sand_entity/6589a48cdeecff/changes/1
execute unless entity @s[scores={s954e4e6406778bc=0,sb1ed806f89e8006=0}] run function rpg:__sand_entity/6589a48cdeecff/reset_internal_causes
scoreboard players set @s s0ba36d9beeab3fd 1
tag @s add __sand.a.6589a48cdeecff