execute if data storage rpg:state __sand_keyed{version:2} run execute unless score @s se09bae1a255736b matches -2147483648.. run scoreboard players set @s se09bae1a255736b 0
execute if data storage rpg:state __sand_keyed{version:2} run execute unless score @s sfe8d54b59e2dece matches -2147483648.. run scoreboard players set @s sfe8d54b59e2dece 0
execute if data storage rpg:state __sand_keyed{version:2} run execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
execute if data storage rpg:state __sand_keyed{version:2} run data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
execute if data storage rpg:state __sand_keyed{version:2} run function unified_state:sand/state_data/keyed/677bf40e with storage rpg:state __sand_owner
execute if data storage rpg:state __sand_keyed{version:2} run function unified_state:sand/state_data/keyed/d816ea4d with storage rpg:state __sand_owner
execute if data storage rpg:state __sand_keyed{version:2} run execute unless score @s s2eb987913797037 matches 1.. run scoreboard players set @s s2eb987913797037 1