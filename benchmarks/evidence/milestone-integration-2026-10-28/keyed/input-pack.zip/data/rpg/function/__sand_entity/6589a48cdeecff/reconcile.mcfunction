scoreboard players set @s s1edcd24c2bebf52 0
execute unless score @s s2eb987913797037 matches 1 run scoreboard players set @s s1edcd24c2bebf52 1
execute unless score @s se09bae1a255736b matches -2147483648.. run scoreboard players set @s s1edcd24c2bebf52 1
execute unless score @s sfe8d54b59e2dece matches -2147483648.. run scoreboard players set @s s1edcd24c2bebf52 1
function rpg:__sand_entity/6589a48cdeecff/provision
execute unless score @s s0ba36d9beeab3fd matches 1 run function rpg:__sand_entity/6589a48cdeecff/initialize
execute if score @s s7b98a5795bc20c5 matches 1 run function rpg:__sand_entity/6589a48cdeecff/changes/0
execute if score @s sd1f3dd6c3704160 matches 1 run function rpg:__sand_entity/6589a48cdeecff/changes/1
execute unless entity @s[scores={s954e4e6406778bc=0,sb1ed806f89e8006=0}] run function rpg:__sand_entity/6589a48cdeecff/reset_internal_causes
execute unless entity @s[scores={s5c0ae00dcbcb155=0,s817c6be26b42ab1=0}] run function rpg:__sand_entity/6589a48cdeecff/acknowledge/0
execute unless entity @s[scores={sd6c86a30e59ce2b=0,s191aaedbe44070f=0}] run function rpg:__sand_entity/6589a48cdeecff/acknowledge/1
execute if score @s s7b98a5795bc20c5 matches 1 run function rpg:__sand_entity/6589a48cdeecff/changes/0
execute if score @s sd1f3dd6c3704160 matches 1 run function rpg:__sand_entity/6589a48cdeecff/changes/1
execute unless entity @s[scores={s954e4e6406778bc=0,sb1ed806f89e8006=0}] run function rpg:__sand_entity/6589a48cdeecff/reset_internal_causes
execute if score @s s7b98a5795bc20c5 matches 1 run function rpg:__sand_entity/6589a48cdeecff/changes/0
execute if score @s sd1f3dd6c3704160 matches 1 run function rpg:__sand_entity/6589a48cdeecff/changes/1
execute unless entity @s[scores={s954e4e6406778bc=0,sb1ed806f89e8006=0}] run function rpg:__sand_entity/6589a48cdeecff/reset_internal_causes