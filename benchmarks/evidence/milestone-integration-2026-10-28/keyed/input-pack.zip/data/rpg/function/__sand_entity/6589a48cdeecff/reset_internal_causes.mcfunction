scoreboard players set @s s954e4e6406778bc 0
scoreboard players set @s sb1ed806f89e8006 0