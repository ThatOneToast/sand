scoreboard objectives add __sj_unified_state.l minecraft.custom:minecraft.leave_game
scoreboard objectives add __sj_unified_state.p dummy
scoreboard objectives add s02089a9adb1b894 dummy
scoreboard objectives add s06bfe54886411ef dummy
scoreboard objectives add s0793fdc221d3ed3 dummy
scoreboard objectives add s08cff6e2a83a8d5 dummy
scoreboard objectives add s0d276454ca24d82 dummy
scoreboard objectives add s0e7e180252e8293 dummy
scoreboard objectives add s107b0821dd576e3 dummy
scoreboard objectives add s1e0781fcab3a98d dummy
scoreboard objectives add s2930231d28e07e1 dummy
scoreboard objectives add s2eb987913797037 dummy
scoreboard objectives add s343ba27454a7529 dummy
scoreboard objectives add s35a3a3e3dbbd5af dummy
scoreboard objectives add s3e301140ad719cb dummy
scoreboard objectives add s3f7e518a2ffb194 dummy
scoreboard objectives add s470e8657b456607 dummy
scoreboard objectives add s48c028b4287d06b dummy
scoreboard objectives add s4a55303c5ca0f62 dummy
scoreboard objectives add s4f1c993b1021717 dummy
scoreboard objectives add s52e928aac683b8c dummy
scoreboard objectives add s5bd00e734ccd771 dummy
scoreboard objectives add s615dcd33728ccd5 dummy
scoreboard objectives add s6645414d0fbd2ad dummy
scoreboard objectives add s6a8028917cf09e2 dummy
scoreboard objectives add s6df686008bc2641 dummy
scoreboard objectives add s7b98a5795bc20c5 dummy
scoreboard objectives add s8b29157c7024c3d dummy
scoreboard objectives add s8fd65628a26b4e0 dummy
scoreboard objectives add saccea77c2a68f21 dummy
scoreboard objectives add sb69a74561ae2585 dummy
scoreboard objectives add sb848191c0c21fa9 dummy
scoreboard objectives add sc227ef935bce78d dummy
scoreboard objectives add sca7b11bbb91961a dummy
scoreboard objectives add sca8b5c75c60c5bd dummy
scoreboard objectives add scf437c73a0c2d28 dummy
scoreboard objectives add sd0045cb1fdd0d57 dummy
scoreboard objectives add sd1f3dd6c3704160 dummy
scoreboard objectives add sdaa1550f79f1e75 dummy
scoreboard objectives add se09bae1a255736b dummy
scoreboard objectives add se1e159acc58be35 dummy
scoreboard objectives add sebc648e1f48bbc5 dummy
scoreboard objectives add sf040c347721ae59 dummy
scoreboard objectives add sf265714b687977e dummy
scoreboard objectives add sf6b3b5339f91c43 dummy
scoreboard objectives add sfe8d54b59e2dece dummy
function unified_state:sand/state_data/migration_provision/739eec93
function unified_state:sand/state_data/migration_provision/bcda7377
execute unless score #sand_rpg_world_102a3fba s08cff6e2a83a8d5 matches -2147483648.. run scoreboard players set #sand_rpg_world_102a3fba s08cff6e2a83a8d5 1
execute unless data storage rpg:state components."world".settings run data modify storage rpg:state components."world".settings set value {difficulty:1,announcements:1b}
execute unless data storage rpg:state components."world".template run data modify storage rpg:state components."world".template set value "$(global)"
execute unless score #sand_rpg_world_102a3fba s343ba27454a7529 matches 1.. run scoreboard players set #sand_rpg_world_102a3fba s343ba27454a7529 1
scoreboard players reset * __sj_unified_state.p