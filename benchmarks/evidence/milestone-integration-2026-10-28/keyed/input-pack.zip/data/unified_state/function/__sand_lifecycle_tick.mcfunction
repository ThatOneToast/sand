execute as @a run function unified_state:__sand_lifecycle_init
execute as @a run function unified_state:__sand_join_check
execute as @e[scores={saccea77c2a68f21=2}] at @s run function unified_state:sand/state_tick/8f6b69d7
execute as @e[scores={s2eb987913797037=1}] at @s run function unified_state:sand/state_tick/c3988963
execute unless data storage rpg:state __sand_keyed{version:2} run function unified_state:sand/state_data/migrate/scf437c73a0c2d28/step
execute unless data storage standalone_probe:state __sand_keyed{version:2} run function unified_state:sand/state_data/migrate/s2930231d28e07e1/step