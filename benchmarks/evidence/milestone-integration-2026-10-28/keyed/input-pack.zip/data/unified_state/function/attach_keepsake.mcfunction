execute if data storage rpg:state __sand_keyed{version:2} run execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
execute if data storage rpg:state __sand_keyed{version:2} run data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
execute if data storage rpg:state __sand_keyed{version:2} run function unified_state:sand/state_data/keyed/43365d2d with storage rpg:state __sand_owner
execute if data storage rpg:state __sand_keyed{version:2} run execute unless score @s s4a55303c5ca0f62 matches 1.. run scoreboard players set @s s4a55303c5ca0f62 1