execute if data storage rpg:state __sand_keyed{version:2} run scoreboard players reset @s sf265714b687977e
execute if data storage rpg:state __sand_keyed{version:2} run function unified_state:sand/state_data/remove/e82e7add
execute if data storage rpg:state __sand_keyed{version:2} run function unified_state:sand/state_data/prune/b2561c78
execute if data storage rpg:state __sand_keyed{version:2} run scoreboard players reset @s s4a55303c5ca0f62