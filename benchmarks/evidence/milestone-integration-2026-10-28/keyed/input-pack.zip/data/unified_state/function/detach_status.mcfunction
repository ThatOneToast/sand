execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run say SAND_STATUS_CLEANUP
execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run scoreboard players get @s se09bae1a255736b
execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run function unified_state:sand/state_data/keyed/ce36e3c9 with storage rpg:state __sand_owner
execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run execute as @e[tag=keyed_literal_b,limit=1] run execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run execute as @e[tag=keyed_literal_b,limit=1] run data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
execute if data storage rpg:state __sand_keyed{version:2} run execute if score @s s2eb987913797037 matches 1.. run execute as @e[tag=keyed_literal_b,limit=1] run function unified_state:sand/state_data/keyed/ce36e3c9 with storage rpg:state __sand_owner
execute if data storage rpg:state __sand_keyed{version:2} run scoreboard players reset @s se09bae1a255736b
execute if data storage rpg:state __sand_keyed{version:2} run scoreboard players reset @s s7b98a5795bc20c5
execute if data storage rpg:state __sand_keyed{version:2} run scoreboard players reset @s sfe8d54b59e2dece
execute if data storage rpg:state __sand_keyed{version:2} run scoreboard players reset @s sd1f3dd6c3704160
execute if data storage rpg:state __sand_keyed{version:2} run scoreboard players reset @s s5bd00e734ccd771
execute if data storage rpg:state __sand_keyed{version:2} run function unified_state:sand/state_data/remove/2f33338e
execute if data storage rpg:state __sand_keyed{version:2} run function unified_state:sand/state_data/remove/4b8fb6ae
execute if data storage rpg:state __sand_keyed{version:2} run function unified_state:sand/state_data/prune/f6755f91
execute if data storage rpg:state __sand_keyed{version:2} run scoreboard players reset @s s2eb987913797037