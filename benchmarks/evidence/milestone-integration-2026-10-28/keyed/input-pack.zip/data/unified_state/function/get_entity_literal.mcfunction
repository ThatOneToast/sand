execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
function unified_state:sand/state_data/keyed/ce36e3c9 with storage rpg:state __sand_owner