scoreboard players set @s se09bae1a255736b 1
execute if score @s se09bae1a255736b matches ..-1 run scoreboard players set @s se09bae1a255736b 0
execute if score @s se09bae1a255736b matches 2.. run scoreboard players set @s se09bae1a255736b 1
scoreboard players set @s s7b98a5795bc20c5 1
scoreboard players set @s s5bd00e734ccd771 1