execute as @e[tag=keyed_literal_b,limit=1] run execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
execute as @e[tag=keyed_literal_b,limit=1] run data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
execute as @e[tag=keyed_literal_b,limit=1] run function unified_state:sand/state_data/keyed/ce36e3c9 with storage rpg:state __sand_owner
execute unless entity @s run data remove storage rpg:state __sand_owner.uuid
data modify storage rpg:state __sand_owner.uuid set from entity @s UUID
function unified_state:sand/state_data/keyed/ce36e3c9 with storage rpg:state __sand_owner
say SAND_KEYED_PRESENT