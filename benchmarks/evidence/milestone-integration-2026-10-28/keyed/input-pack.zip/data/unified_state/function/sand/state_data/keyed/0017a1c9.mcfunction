execute unless data storage rpg:state __sand_keyed{version:2} run return fail
$execute if data storage rpg:state owners_v2."$(uuid)".components."status"{} store result storage rpg:state __sand_owner.children int 1 run data get storage rpg:state owners_v2."$(uuid)".components."status"
$execute if data storage rpg:state owners_v2."$(uuid)".components."status"{} if data storage rpg:state __sand_owner{children:0} run data remove storage rpg:state owners_v2."$(uuid)".components."status"
$execute if data storage rpg:state owners_v2."$(uuid)".components{} store result storage rpg:state __sand_owner.children int 1 run data get storage rpg:state owners_v2."$(uuid)".components
$execute if data storage rpg:state owners_v2."$(uuid)".components{} if data storage rpg:state __sand_owner{children:0} run data remove storage rpg:state owners_v2."$(uuid)".components
$execute if data storage rpg:state owners_v2."$(uuid)"{uuid:$(uuid)} store result storage rpg:state __sand_owner.children int 1 run data get storage rpg:state owners_v2."$(uuid)"
$execute if data storage rpg:state owners_v2."$(uuid)"{uuid:$(uuid)} if data storage rpg:state __sand_owner{children:1} run data remove storage rpg:state owners_v2."$(uuid)"
data remove storage rpg:state __sand_owner.children