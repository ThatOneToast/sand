execute unless data storage rpg:state __sand_keyed{version:2} run return fail
$data remove storage rpg:state owners_v2."$(uuid)".components."status".template