execute unless data storage rpg:state __sand_keyed{version:2} run return fail
$execute unless data storage rpg:state owners_v2."$(uuid)" run data modify storage rpg:state owners_v2."$(uuid)" set value {uuid:$(uuid),components:{}}
$execute unless data storage rpg:state owners_v2."$(uuid)".components."keepsake".memory run function unified_state:sand/state_data/write/365cc25f