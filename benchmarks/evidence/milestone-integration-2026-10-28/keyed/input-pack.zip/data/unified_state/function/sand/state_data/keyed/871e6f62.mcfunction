execute unless data storage rpg:state __sand_keyed{version:2} run return fail
$execute unless data storage rpg:state owners_v2."$(uuid)" run data modify storage rpg:state owners_v2."$(uuid)" set value {uuid:$(uuid),components:{}}
$data modify storage rpg:state owners_v2."$(uuid)".components."status".template set from storage rpg:state __sand_owner.value