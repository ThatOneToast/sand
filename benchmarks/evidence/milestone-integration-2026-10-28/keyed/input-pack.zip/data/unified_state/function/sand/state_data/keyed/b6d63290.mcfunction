execute unless data storage rpg:state __sand_keyed{version:2} run return fail
$execute unless data storage rpg:state owners_v2."$(uuid)" run data modify storage rpg:state owners_v2."$(uuid)" set value {uuid:$(uuid),components:{}}
$execute unless data storage rpg:state owners_v2."$(uuid)".components."progression".preferences run function unified_state:sand/state_data/write/8ce5071b