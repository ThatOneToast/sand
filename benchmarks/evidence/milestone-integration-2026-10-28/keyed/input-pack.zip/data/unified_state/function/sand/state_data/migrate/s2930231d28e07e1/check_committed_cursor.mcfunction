scoreboard players remove #cursor s2930231d28e07e1 1
execute unless score #next s2930231d28e07e1 = #cursor s2930231d28e07e1 run function unified_state:sand/state_data/migration_error/7a628fdb