execute store result score #cursor s2930231d28e07e1 run data get storage standalone_probe:state __sand_keyed.cursor
execute store result score #next s2930231d28e07e1 run data get storage standalone_probe:state __sand_keyed.journal.next
execute store result storage standalone_probe:state __sand_keyed.next_number int 1 run scoreboard players get #next s2930231d28e07e1
data modify storage standalone_probe:state __sand_keyed.next_check set from storage standalone_probe:state __sand_keyed.journal.next
execute store success storage standalone_probe:state __sand_keyed.bad_next int 1 run data modify storage standalone_probe:state __sand_keyed.next_check set from storage standalone_probe:state __sand_keyed.next_number
execute if data storage standalone_probe:state __sand_keyed{bad_next:1} run function unified_state:sand/state_data/migration_error/7a628fdb
scoreboard players add #cursor s2930231d28e07e1 1
execute unless score #next s2930231d28e07e1 = #cursor s2930231d28e07e1 run function unified_state:sand/state_data/migrate/s2930231d28e07e1/check_committed_cursor
execute if data storage standalone_probe:state __sand_keyed.error run return fail
data modify storage standalone_probe:state __sand_keyed.cursor set from storage standalone_probe:state __sand_keyed.journal.next
data remove storage standalone_probe:state __sand_keyed.journal