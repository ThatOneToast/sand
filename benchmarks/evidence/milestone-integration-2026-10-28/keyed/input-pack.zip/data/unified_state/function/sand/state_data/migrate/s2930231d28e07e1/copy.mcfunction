$execute if data storage standalone_probe:state owners_v2."$(uuid)" unless data storage standalone_probe:state __sand_keyed.journal{intent:1b} run function unified_state:sand/state_data/migration_error/4ac3ebb9
execute if data storage standalone_probe:state __sand_keyed.error run return fail
data modify storage standalone_probe:state __sand_keyed.journal.intent set value 1b
$execute unless data storage standalone_probe:state owners_v2."$(uuid)" run data modify storage standalone_probe:state owners_v2."$(uuid)" set from storage standalone_probe:state __sand_keyed.journal.row
$execute unless data storage standalone_probe:state owners_v2."$(uuid)" run function unified_state:sand/state_data/migration_error/4ac3ebb9
execute if data storage standalone_probe:state __sand_keyed.error run return fail
$data modify storage standalone_probe:state __sand_keyed.compare set from storage standalone_probe:state owners_v2."$(uuid)"
execute store success storage standalone_probe:state __sand_keyed.different int 1 run data modify storage standalone_probe:state __sand_keyed.compare set from storage standalone_probe:state __sand_keyed.journal.row
execute if data storage standalone_probe:state __sand_keyed{different:1} run function unified_state:sand/state_data/migration_error/4ac3ebb9
execute if data storage standalone_probe:state __sand_keyed.error run return fail
data modify storage standalone_probe:state __sand_keyed.journal.done set value 1b