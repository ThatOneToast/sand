data modify storage standalone_probe:state __sand_keyed.finishing set value 1b
data remove storage standalone_probe:state owners
data modify storage standalone_probe:state __sand_keyed set value {version:2}