$execute unless data storage standalone_probe:state __sand_keyed.journal.row run data modify storage standalone_probe:state __sand_keyed.journal.row set from storage standalone_probe:state owners[$(cursor)]
execute unless data storage standalone_probe:state __sand_keyed.journal.row.components{} run function unified_state:sand/state_data/migration_error/5cba85bd
execute if data storage standalone_probe:state __sand_keyed.error run return fail
execute store result storage standalone_probe:state __sand_keyed.length int 1 run data get storage standalone_probe:state __sand_keyed.journal.row.uuid
execute unless data storage standalone_probe:state __sand_keyed{length:4} run function unified_state:sand/state_data/migration_error/5cba85bd
execute if data storage standalone_probe:state __sand_keyed.error run return fail
execute store result storage standalone_probe:state __sand_keyed.args.u0 int 1 run data get storage standalone_probe:state __sand_keyed.journal.row.uuid[0]
execute store result storage standalone_probe:state __sand_keyed.args.u1 int 1 run data get storage standalone_probe:state __sand_keyed.journal.row.uuid[1]
execute store result storage standalone_probe:state __sand_keyed.args.u2 int 1 run data get storage standalone_probe:state __sand_keyed.journal.row.uuid[2]
execute store result storage standalone_probe:state __sand_keyed.args.u3 int 1 run data get storage standalone_probe:state __sand_keyed.journal.row.uuid[3]
execute store result score #cursor s2930231d28e07e1 run data get storage standalone_probe:state __sand_keyed.cursor
scoreboard players add #cursor s2930231d28e07e1 1
execute unless data storage standalone_probe:state __sand_keyed.journal.next store result storage standalone_probe:state __sand_keyed.journal.next int 1 run scoreboard players get #cursor s2930231d28e07e1
function unified_state:sand/state_data/migrate/s2930231d28e07e1/validate with storage standalone_probe:state __sand_keyed.args