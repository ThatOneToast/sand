function unified_state:sand/state_data/migrate/s2930231d28e07e1/prepare with storage standalone_probe:state __sand_keyed
execute if data storage standalone_probe:state __sand_keyed.error run return fail
execute if data storage standalone_probe:state __sand_keyed.journal{done:1b} run function unified_state:sand/state_data/migrate/s2930231d28e07e1/commit