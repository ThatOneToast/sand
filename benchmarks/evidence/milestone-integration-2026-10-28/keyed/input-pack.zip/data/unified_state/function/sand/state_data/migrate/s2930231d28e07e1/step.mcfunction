execute if data storage standalone_probe:state __sand_keyed{version:2} run return 0
execute if data storage standalone_probe:state __sand_keyed.error run return fail
execute unless data storage standalone_probe:state __sand_keyed{} run return run function unified_state:sand/state_data/migration_error/7a628fdb
execute unless data storage standalone_probe:state __sand_keyed{version:1} run function unified_state:sand/state_data/migration_error/7a628fdb
execute if data storage standalone_probe:state __sand_keyed.error run return fail
execute unless data storage standalone_probe:state __sand_keyed.cursor run function unified_state:sand/state_data/migration_error/7a628fdb
execute if data storage standalone_probe:state __sand_keyed.error run return fail
execute store result storage standalone_probe:state __sand_keyed.cursor_number int 1 run data get storage standalone_probe:state __sand_keyed.cursor
data modify storage standalone_probe:state __sand_keyed.cursor_check set from storage standalone_probe:state __sand_keyed.cursor
execute store success storage standalone_probe:state __sand_keyed.bad_cursor int 1 run data modify storage standalone_probe:state __sand_keyed.cursor_check set from storage standalone_probe:state __sand_keyed.cursor_number
execute if data storage standalone_probe:state __sand_keyed{bad_cursor:1} run function unified_state:sand/state_data/migration_error/7a628fdb
execute if data storage standalone_probe:state __sand_keyed.error run return fail
execute if data storage standalone_probe:state __sand_keyed{finishing:1b} run return run function unified_state:sand/state_data/migrate/s2930231d28e07e1/finish
execute if data storage standalone_probe:state __sand_keyed.journal{done:1b} run return run function unified_state:sand/state_data/migrate/s2930231d28e07e1/resume
execute store result score #length s2930231d28e07e1 run data get storage standalone_probe:state owners
execute store result score #cursor s2930231d28e07e1 run data get storage standalone_probe:state __sand_keyed.cursor
execute unless score #cursor s2930231d28e07e1 matches 0.. run function unified_state:sand/state_data/migration_error/7a628fdb
execute if score #cursor s2930231d28e07e1 > #length s2930231d28e07e1 run function unified_state:sand/state_data/migration_error/7a628fdb
execute if data storage standalone_probe:state __sand_keyed.error run return fail
execute if score #length s2930231d28e07e1 matches 0 unless data storage standalone_probe:state {owners:[]} run function unified_state:sand/state_data/migration_error/7a628fdb
execute if data storage standalone_probe:state __sand_keyed.error run return fail
execute if score #cursor s2930231d28e07e1 = #length s2930231d28e07e1 run return run function unified_state:sand/state_data/migrate/s2930231d28e07e1/finish
function unified_state:sand/state_data/migrate/s2930231d28e07e1/prepare with storage standalone_probe:state __sand_keyed