$execute unless data storage standalone_probe:state __sand_keyed.journal.row{uuid:[I;$(u0),$(u1),$(u2),$(u3)]} run function unified_state:sand/state_data/migration_error/5cba85bd
execute if data storage standalone_probe:state __sand_keyed.error run return fail
function unified_state:sand/state_data/migrate/s2930231d28e07e1/copy with storage standalone_probe:state __sand_keyed.journal.row