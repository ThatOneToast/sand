scoreboard players remove #cursor scf437c73a0c2d28 1
execute unless score #next scf437c73a0c2d28 = #cursor scf437c73a0c2d28 run function unified_state:sand/state_data/migration_error/6731f9b5