execute store result score #cursor scf437c73a0c2d28 run data get storage rpg:state __sand_keyed.cursor
execute store result score #next scf437c73a0c2d28 run data get storage rpg:state __sand_keyed.journal.next
execute store result storage rpg:state __sand_keyed.next_number int 1 run scoreboard players get #next scf437c73a0c2d28
data modify storage rpg:state __sand_keyed.next_check set from storage rpg:state __sand_keyed.journal.next
execute store success storage rpg:state __sand_keyed.bad_next int 1 run data modify storage rpg:state __sand_keyed.next_check set from storage rpg:state __sand_keyed.next_number
execute if data storage rpg:state __sand_keyed{bad_next:1} run function unified_state:sand/state_data/migration_error/6731f9b5
scoreboard players add #cursor scf437c73a0c2d28 1
execute unless score #next scf437c73a0c2d28 = #cursor scf437c73a0c2d28 run function unified_state:sand/state_data/migrate/scf437c73a0c2d28/check_committed_cursor
execute if data storage rpg:state __sand_keyed.error run return fail
data modify storage rpg:state __sand_keyed.cursor set from storage rpg:state __sand_keyed.journal.next
data remove storage rpg:state __sand_keyed.journal