data modify storage rpg:state __sand_keyed.finishing set value 1b
data remove storage rpg:state owners
data modify storage rpg:state __sand_keyed set value {version:2}