$execute unless data storage rpg:state __sand_keyed.journal.row run data modify storage rpg:state __sand_keyed.journal.row set from storage rpg:state owners[$(cursor)]
execute unless data storage rpg:state __sand_keyed.journal.row.components{} run function unified_state:sand/state_data/migration_error/98dd41ed
execute if data storage rpg:state __sand_keyed.error run return fail
execute store result storage rpg:state __sand_keyed.length int 1 run data get storage rpg:state __sand_keyed.journal.row.uuid
execute unless data storage rpg:state __sand_keyed{length:4} run function unified_state:sand/state_data/migration_error/98dd41ed
execute if data storage rpg:state __sand_keyed.error run return fail
execute store result storage rpg:state __sand_keyed.args.u0 int 1 run data get storage rpg:state __sand_keyed.journal.row.uuid[0]
execute store result storage rpg:state __sand_keyed.args.u1 int 1 run data get storage rpg:state __sand_keyed.journal.row.uuid[1]
execute store result storage rpg:state __sand_keyed.args.u2 int 1 run data get storage rpg:state __sand_keyed.journal.row.uuid[2]
execute store result storage rpg:state __sand_keyed.args.u3 int 1 run data get storage rpg:state __sand_keyed.journal.row.uuid[3]
execute store result score #cursor scf437c73a0c2d28 run data get storage rpg:state __sand_keyed.cursor
scoreboard players add #cursor scf437c73a0c2d28 1
execute unless data storage rpg:state __sand_keyed.journal.next store result storage rpg:state __sand_keyed.journal.next int 1 run scoreboard players get #cursor scf437c73a0c2d28
function unified_state:sand/state_data/migrate/scf437c73a0c2d28/validate with storage rpg:state __sand_keyed.args