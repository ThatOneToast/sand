function unified_state:sand/state_data/migrate/scf437c73a0c2d28/prepare with storage rpg:state __sand_keyed
execute if data storage rpg:state __sand_keyed.error run return fail
execute if data storage rpg:state __sand_keyed.journal{done:1b} run function unified_state:sand/state_data/migrate/scf437c73a0c2d28/commit