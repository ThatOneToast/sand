execute if data storage rpg:state __sand_keyed{version:2} run return 0
execute if data storage rpg:state __sand_keyed.error run return fail
execute unless data storage rpg:state __sand_keyed{} run return run function unified_state:sand/state_data/migration_error/6731f9b5
execute unless data storage rpg:state __sand_keyed{version:1} run function unified_state:sand/state_data/migration_error/6731f9b5
execute if data storage rpg:state __sand_keyed.error run return fail
execute unless data storage rpg:state __sand_keyed.cursor run function unified_state:sand/state_data/migration_error/6731f9b5
execute if data storage rpg:state __sand_keyed.error run return fail
execute store result storage rpg:state __sand_keyed.cursor_number int 1 run data get storage rpg:state __sand_keyed.cursor
data modify storage rpg:state __sand_keyed.cursor_check set from storage rpg:state __sand_keyed.cursor
execute store success storage rpg:state __sand_keyed.bad_cursor int 1 run data modify storage rpg:state __sand_keyed.cursor_check set from storage rpg:state __sand_keyed.cursor_number
execute if data storage rpg:state __sand_keyed{bad_cursor:1} run function unified_state:sand/state_data/migration_error/6731f9b5
execute if data storage rpg:state __sand_keyed.error run return fail
execute if data storage rpg:state __sand_keyed{finishing:1b} run return run function unified_state:sand/state_data/migrate/scf437c73a0c2d28/finish
execute if data storage rpg:state __sand_keyed.journal{done:1b} run return run function unified_state:sand/state_data/migrate/scf437c73a0c2d28/resume
execute store result score #length scf437c73a0c2d28 run data get storage rpg:state owners
execute store result score #cursor scf437c73a0c2d28 run data get storage rpg:state __sand_keyed.cursor
execute unless score #cursor scf437c73a0c2d28 matches 0.. run function unified_state:sand/state_data/migration_error/6731f9b5
execute if score #cursor scf437c73a0c2d28 > #length scf437c73a0c2d28 run function unified_state:sand/state_data/migration_error/6731f9b5
execute if data storage rpg:state __sand_keyed.error run return fail
execute if score #length scf437c73a0c2d28 matches 0 unless data storage rpg:state {owners:[]} run function unified_state:sand/state_data/migration_error/6731f9b5
execute if data storage rpg:state __sand_keyed.error run return fail
execute if score #cursor scf437c73a0c2d28 = #length scf437c73a0c2d28 run return run function unified_state:sand/state_data/migrate/scf437c73a0c2d28/finish
function unified_state:sand/state_data/migrate/scf437c73a0c2d28/prepare with storage rpg:state __sand_keyed