$execute unless data storage rpg:state __sand_keyed.journal.row{uuid:[I;$(u0),$(u1),$(u2),$(u3)]} run function unified_state:sand/state_data/migration_error/98dd41ed
execute if data storage rpg:state __sand_keyed.error run return fail
function unified_state:sand/state_data/migrate/scf437c73a0c2d28/copy with storage rpg:state __sand_keyed.journal.row