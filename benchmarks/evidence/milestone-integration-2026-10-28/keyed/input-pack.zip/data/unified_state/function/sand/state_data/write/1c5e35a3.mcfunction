data remove storage rpg:state __sand_owner.value
data modify storage rpg:state __sand_owner.value set value {stacks:0,note:"clean"}
function unified_state:sand/state_data/keyed/5372f5fb with storage rpg:state __sand_owner
data remove storage rpg:state __sand_owner.value