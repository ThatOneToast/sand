data remove storage rpg:state __sand_owner.value
data modify storage rpg:state __sand_owner.value set value {value:19}
function unified_state:sand/state_data/keyed/02dcf30d with storage rpg:state __sand_owner
data remove storage rpg:state __sand_owner.value