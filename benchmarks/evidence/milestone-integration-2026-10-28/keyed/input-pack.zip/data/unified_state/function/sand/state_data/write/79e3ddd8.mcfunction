data remove storage standalone_probe:state __sand_owner.value
data modify storage standalone_probe:state __sand_owner.value set value "$(missing) $(u0) \"quoted\" \\ path"
execute unless entity @s run data remove storage standalone_probe:state __sand_owner.uuid
data modify storage standalone_probe:state __sand_owner.uuid set from entity @s UUID
function unified_state:sand/state_data/keyed/b9b6f894 with storage standalone_probe:state __sand_owner
data remove storage standalone_probe:state __sand_owner.value