scoreboard players set @s __sd_trail.c 0
execute at @s run function trail:on_death