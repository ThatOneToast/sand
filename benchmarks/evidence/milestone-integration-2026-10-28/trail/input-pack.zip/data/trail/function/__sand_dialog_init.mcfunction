scoreboard objectives add sand.dialog trigger
scoreboard players enable @a sand.dialog