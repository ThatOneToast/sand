scoreboard players enable @a sand.dialog
execute as @a[scores={sand.dialog=1}] at @s run function trail:grapple
scoreboard players set @a[scores={sand.dialog=1}] sand.dialog 0
scoreboard players enable @a sand.dialog
execute as @a[scores={sand.dialog=2}] at @s run function trail:claim_striders
scoreboard players set @a[scores={sand.dialog=2}] sand.dialog 0
scoreboard players enable @a sand.dialog