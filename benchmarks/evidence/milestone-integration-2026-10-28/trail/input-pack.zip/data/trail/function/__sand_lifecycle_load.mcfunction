scoreboard objectives add __sd_trail.c deathCount
scoreboard objectives add s5d6868466971a59 dummy
scoreboard objectives add s75ce4395fd466a3 dummy
scoreboard objectives add s8520e22d64708b4 dummy
scoreboard objectives add s9b03f7001255338 dummy
scoreboard objectives add sa9c5ae898ac8f8e dummy
scoreboard objectives add saafb19392893dee dummy
scoreboard objectives add scf21a43c2b92f8a dummy
scoreboard objectives add sfa49ff66aebe47c dummy
function trail:__sand_system/raycast/grapple/load
function trail:__sand_system/raycast/scout/load