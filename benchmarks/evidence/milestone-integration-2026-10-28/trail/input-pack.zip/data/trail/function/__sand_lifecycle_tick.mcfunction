execute as @a run function trail:__sand_lifecycle_init
execute as @a run execute if score @s sa9c5ae898ac8f8e matches 1.. if score @s scf21a43c2b92f8a matches 1.. run scoreboard players remove @s scf21a43c2b92f8a 1
execute as @a run execute if score @s sa9c5ae898ac8f8e matches 1.. if score @s s8520e22d64708b4 matches 1.. run scoreboard players remove @s s8520e22d64708b4 1
execute as @a run function trail:__sand_death_check
function trail:stamina/maintain