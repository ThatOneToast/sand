execute unless score @s sfc94f915cb3ba15 matches 1..256 run return 0
execute if score @s sfc94f915cb3ba15 matches 1 run return run execute positioned ^ ^ ^0.25 run function trail:__sand_system/raycast/grapple/sample
return run execute positioned ^ ^ ^0.25 run function trail:__sand_system/raycast/grapple/sample