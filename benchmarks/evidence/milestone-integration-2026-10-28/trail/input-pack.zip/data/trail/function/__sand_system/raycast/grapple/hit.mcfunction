scoreboard players reset @s sfc94f915cb3ba15
return run execute if entity @s[type=minecraft:player] run function trail:grapple/hit