scoreboard players reset @s sfc94f915cb3ba15
return 0