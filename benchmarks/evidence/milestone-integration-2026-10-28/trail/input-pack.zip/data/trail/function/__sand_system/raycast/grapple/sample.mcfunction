scoreboard players remove @s sfc94f915cb3ba15 1
execute unless loaded ~ ~ ~ run return run function trail:__sand_system/raycast/grapple/miss
execute unless predicate trail:__sand_system/raycast/grapple/valid_sample run return run function trail:__sand_system/raycast/grapple/miss
execute unless predicate trail:__sand_system/raycast/grapple/criterion run return run function trail:__sand_system/raycast/grapple/hit
execute if score @s sfc94f915cb3ba15 matches 0 run return run function trail:__sand_system/raycast/grapple/miss
return run function trail:__sand_system/raycast/grapple/advance