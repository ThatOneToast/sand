execute unless entity @s run return 0
scoreboard players set @s sfc94f915cb3ba15 32
return run execute anchored eyes positioned ^ ^ ^ anchored feet run function trail:__sand_system/raycast/grapple/advance