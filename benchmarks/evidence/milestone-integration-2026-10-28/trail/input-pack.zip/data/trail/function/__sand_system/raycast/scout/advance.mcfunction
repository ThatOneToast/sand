execute unless score @s s674791d9a7b09dc matches 1..256 run return 0
execute if score @s s674791d9a7b09dc matches 1 run return run execute positioned ^ ^ ^0.25 run function trail:__sand_system/raycast/scout/sample
return run execute positioned ^ ^ ^0.25 run function trail:__sand_system/raycast/scout/sample