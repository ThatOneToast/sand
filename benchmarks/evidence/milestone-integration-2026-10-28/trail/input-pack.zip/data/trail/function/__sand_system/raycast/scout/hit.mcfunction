scoreboard players reset @s s674791d9a7b09dc
return run execute if entity @s[type=minecraft:player] run function trail:scout/hit