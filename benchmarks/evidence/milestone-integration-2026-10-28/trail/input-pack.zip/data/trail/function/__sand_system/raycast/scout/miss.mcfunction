scoreboard players reset @s s674791d9a7b09dc
return 0