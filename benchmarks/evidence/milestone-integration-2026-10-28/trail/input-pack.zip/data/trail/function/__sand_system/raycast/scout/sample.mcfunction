scoreboard players remove @s s674791d9a7b09dc 1
execute unless loaded ~ ~ ~ run return run function trail:__sand_system/raycast/scout/miss
execute unless predicate trail:__sand_system/raycast/scout/valid_sample run return run function trail:__sand_system/raycast/scout/miss
execute unless predicate trail:__sand_system/raycast/scout/criterion run return run function trail:__sand_system/raycast/scout/hit
execute if score @s s674791d9a7b09dc matches 0 run return run function trail:__sand_system/raycast/scout/miss
return run function trail:__sand_system/raycast/scout/advance