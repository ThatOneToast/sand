execute unless entity @s run return 0
scoreboard players set @s s674791d9a7b09dc 16
return run execute anchored eyes positioned ^ ^ ^ anchored feet run function trail:__sand_system/raycast/scout/advance