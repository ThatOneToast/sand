setworldspawn 0 65 0 0 0
fill -4 64 -4 4 64 4 minecraft:stone
gamerule keep_inventory true
time set 6000
gamerule advance_time false
