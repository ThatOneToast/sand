function trail:__sand_lifecycle_init
effect give @s minecraft:speed 3 2 true
effect give @s minecraft:slow_falling 4 0 true
execute at @s run particle minecraft:cloud ~0 ~0 ~0 0.4 0.2 0.4 0 24 force
execute at @s run playsound minecraft:entity.ender_pearl.throw player @s ~ ~ ~ 0.8 1.4
tellraw @s {"color":"aqua","text":"Whoosh!"}