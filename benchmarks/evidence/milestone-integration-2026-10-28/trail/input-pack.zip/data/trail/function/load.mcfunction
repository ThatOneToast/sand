data modify storage trail:data config.grapple_range set value 8
tellraw @a {"color":"gold","text":"[Trailforge] loaded."}