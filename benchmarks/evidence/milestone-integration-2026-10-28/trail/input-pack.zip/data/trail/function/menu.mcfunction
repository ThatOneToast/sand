function trail:__sand_lifecycle_init
dialog show @s trail:trailhead