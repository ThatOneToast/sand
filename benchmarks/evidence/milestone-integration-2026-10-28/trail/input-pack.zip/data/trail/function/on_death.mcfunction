scoreboard players set @s saafb19392893dee 0
execute if score @s saafb19392893dee matches ..-1 run scoreboard players set @s saafb19392893dee 0
execute if score @s saafb19392893dee matches 2.. run scoreboard players set @s saafb19392893dee 1
scoreboard players set @s scf21a43c2b92f8a 0
execute if score @s scf21a43c2b92f8a matches ..-1 run scoreboard players set @s scf21a43c2b92f8a 0
scoreboard players set @s sfa49ff66aebe47c 100