scoreboard players set @s sfa49ff66aebe47c 100
title @s times 10 70 20
title @s subtitle {"color":"aqua","text":"Craft a Grapple Core to begin"}
title @s title {"bold":true,"color":"gold","text":"Trailforge"}