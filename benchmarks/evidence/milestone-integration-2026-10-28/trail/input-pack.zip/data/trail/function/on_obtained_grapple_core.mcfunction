advancement revoke @s only trail:on_obtained_grapple_core
execute unless score @s s9b03f7001255338 matches 0 run return 0
function trail:on_obtained_grapple_core/body