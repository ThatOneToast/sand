tellraw @s {"color":"aqua","text":"The core hums. Run /function trail:claim_striders"}
function trail:menu