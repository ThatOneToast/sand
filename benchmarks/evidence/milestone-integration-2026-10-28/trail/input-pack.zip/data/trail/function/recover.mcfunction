function trail:__sand_lifecycle_init
scoreboard players set @s saafb19392893dee 0
execute if score @s saafb19392893dee matches ..-1 run scoreboard players set @s saafb19392893dee 0
execute if score @s saafb19392893dee matches 2.. run scoreboard players set @s saafb19392893dee 1
tellraw @s {"color":"green","text":"You feel steady again."}