execute if function trail:sand/conditions/numeric/0870e94c run function trail:state_mutation/2591f404
scoreboard players set @s s8520e22d64708b4 40
execute if score @s s8520e22d64708b4 matches ..-1 run scoreboard players set @s s8520e22d64708b4 0