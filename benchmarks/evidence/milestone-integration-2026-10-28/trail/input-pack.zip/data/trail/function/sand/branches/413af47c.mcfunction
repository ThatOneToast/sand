execute if score @s s9b03f7001255338 matches 1 run return run function trail:sand/branches/5c49977e
return run function trail:sand/branches/991201e2