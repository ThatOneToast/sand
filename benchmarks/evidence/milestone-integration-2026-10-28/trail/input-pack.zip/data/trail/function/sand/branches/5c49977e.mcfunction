tellraw @s {"color":"red","text":"You already unlocked Trail Striders."}
return fail