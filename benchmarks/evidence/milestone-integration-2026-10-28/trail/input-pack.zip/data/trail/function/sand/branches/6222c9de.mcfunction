execute if function trail:sand/conditions/numeric/f1270ba9 run return run function trail:sand/branches/80b987ab
return run function trail:sand/branches/b7b2ae86