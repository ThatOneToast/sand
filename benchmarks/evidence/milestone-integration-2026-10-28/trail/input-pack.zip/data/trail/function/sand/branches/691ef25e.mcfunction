function trail:state_mutation/78141a69
scoreboard players set @s scf21a43c2b92f8a 80
execute if score @s scf21a43c2b92f8a matches ..-1 run scoreboard players set @s scf21a43c2b92f8a 0
function trail:grapple/execute