execute as @s run clear @s minecraft:heart_of_the_sea[minecraft:custom_data~{grapple_core:1b}] 1
give @s minecraft:leather_boots[custom_data={trail_striders:1b},custom_name={bold:true,color:"gold",text:"Trail Striders"},lore=[{color:"gray",text:"Light as a rumor"}],rarity="epic",attribute_modifiers=[{id:"minecraft:movement_speed",type:"minecraft:movement_speed",amount:0.02d,operation:"add_value",slot:"feet"}]]
scoreboard players set @s s9b03f7001255338 1
execute if score @s s9b03f7001255338 matches ..-1 run scoreboard players set @s s9b03f7001255338 0
execute if score @s s9b03f7001255338 matches 2.. run scoreboard players set @s s9b03f7001255338 1
tellraw @s {"color":"gold","text":"Trail Striders unlocked. Equip your new boots!"}
return 1