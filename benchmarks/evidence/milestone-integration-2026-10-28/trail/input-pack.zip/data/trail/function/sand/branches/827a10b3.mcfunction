function trail:state_mutation/cc055adf
scoreboard players set @s scf21a43c2b92f8a 20
execute if score @s scf21a43c2b92f8a matches ..-1 run scoreboard players set @s scf21a43c2b92f8a 0
function trail:scout/execute