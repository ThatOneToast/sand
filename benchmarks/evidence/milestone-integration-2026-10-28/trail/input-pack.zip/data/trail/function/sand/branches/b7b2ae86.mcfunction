tellraw @s {"color":"red","text":"Craft a Grapple Core before claiming Trail Striders."}
return fail