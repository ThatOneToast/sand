execute if block ~ ~ ~ minecraft:iron_block run return 1
return 0