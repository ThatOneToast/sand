execute if block ~ ~ ~ minecraft:gold_block run return 1
return 0