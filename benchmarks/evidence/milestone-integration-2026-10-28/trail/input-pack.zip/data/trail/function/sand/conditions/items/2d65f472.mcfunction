execute if items entity @s armor.feet minecraft:leather_boots[minecraft:custom_data~{trail_striders:1b}] run return 1
return 0