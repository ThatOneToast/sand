scoreboard players set #comparison se1f34c4d8625ef0 0
execute store success score #comparison s9312b5b9c6582af store result score #comparison se1f34c4d8625ef0 run scoreboard players get @s sfa49ff66aebe47c
execute unless score #comparison s9312b5b9c6582af matches 1 run return fail
scoreboard players operation #comparison s049639fbd169206 = #comparison se1f34c4d8625ef0
scoreboard players set #comparison s93afd1788787537 100
scoreboard players operation #comparison sc8d473d014aca87 = #comparison s93afd1788787537
execute if score #comparison s049639fbd169206 < #comparison sc8d473d014aca87 run return 1
return 0