scoreboard players set #inventory sdfbe983d7759361 0
execute as @s run function trail:sand/conditions/numeric/f1270ba9/left/inventory_0
execute unless score #inventory sdfbe983d7759361 matches 1 run return fail
scoreboard players operation #comparison sad95ec84ffc4f8a = #inventory s193bb233072cfc4
scoreboard players operation #comparison s9d1364dd0a5ae54 = #comparison sad95ec84ffc4f8a
scoreboard players set #comparison s0fa701d5d157351 0
scoreboard players operation #comparison s0f683d32a112765 = #comparison s0fa701d5d157351
execute if score #comparison s9d1364dd0a5ae54 > #comparison s0f683d32a112765 run return 1
return 0