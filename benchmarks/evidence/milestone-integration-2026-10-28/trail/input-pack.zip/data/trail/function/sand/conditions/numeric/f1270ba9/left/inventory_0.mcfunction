execute unless entity @s[type=minecraft:player] run return fail
scoreboard players set #inventory sdfbe983d7759361 1
execute store result score #inventory s193bb233072cfc4 run clear @s minecraft:heart_of_the_sea[minecraft:custom_data~{grapple_core:1b}] 0