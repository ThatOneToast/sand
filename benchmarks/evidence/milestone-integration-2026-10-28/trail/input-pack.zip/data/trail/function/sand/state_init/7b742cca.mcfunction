execute unless score @s s5d6868466971a59 matches 1.. unless score @s sfa49ff66aebe47c matches -2147483648.. run scoreboard players set @s sfa49ff66aebe47c 100
execute unless score @s s5d6868466971a59 matches 1.. unless score @s scf21a43c2b92f8a matches -2147483648.. run scoreboard players set @s scf21a43c2b92f8a 0
execute unless score @s s5d6868466971a59 matches 1.. unless score @s s9b03f7001255338 matches -2147483648.. run scoreboard players set @s s9b03f7001255338 0
execute unless score @s s5d6868466971a59 matches 1.. unless score @s saafb19392893dee matches -2147483648.. run scoreboard players set @s saafb19392893dee 0
execute unless score @s s5d6868466971a59 matches 1.. unless score @s s8520e22d64708b4 matches -2147483648.. run scoreboard players set @s s8520e22d64708b4 0
execute unless score @s s5d6868466971a59 matches 1.. unless score @s sa9c5ae898ac8f8e matches 1.. run scoreboard players set @s sa9c5ae898ac8f8e 1