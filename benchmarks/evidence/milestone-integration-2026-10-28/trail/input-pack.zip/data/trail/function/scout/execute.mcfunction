function trail:__sand_lifecycle_init
effect give @s minecraft:speed 1 0 true