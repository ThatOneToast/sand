scoreboard players remove @s sfa49ff66aebe47c 10
execute if score @s sfa49ff66aebe47c matches ..-1 run scoreboard players set @s sfa49ff66aebe47c 0
execute if score @s sfa49ff66aebe47c matches 101.. run scoreboard players set @s sfa49ff66aebe47c 100